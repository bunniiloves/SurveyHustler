import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";

import Dashboard from "@/pages/dashboard";
import ActiveSurveys from "@/pages/active-surveys";
import ProfileManager from "@/pages/profile-manager";
import BotSettings from "@/pages/bot-settings";
import ResponseTemplates from "@/pages/response-templates";
import SurveyHistory from "@/pages/survey-history";
import EarningsReport from "@/pages/earnings-report";
import NotFound from "@/pages/not-found";
import { useState } from "react";

function App() {
  const [location] = useLocation();
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  const toggleSidebar = () => {
    setShowMobileSidebar(!showMobileSidebar);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar showMobile={showMobileSidebar} currentPath={location} onCloseMobile={() => setShowMobileSidebar(false)} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <MobileHeader onToggleSidebar={toggleSidebar} />
          <main className="flex-1 overflow-y-auto">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/active-surveys" component={ActiveSurveys} />
              <Route path="/profile-manager" component={ProfileManager} />
              <Route path="/bot-settings" component={BotSettings} />
              <Route path="/response-templates" component={ResponseTemplates} />
              <Route path="/survey-history" component={SurveyHistory} />
              <Route path="/earnings-report" component={EarningsReport} />
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
