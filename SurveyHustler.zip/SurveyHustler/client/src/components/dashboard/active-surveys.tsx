import { Card, CardHeader, CardContent, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter, SortAsc, ChevronLeft, ChevronRight, ClipboardList } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

export default function ActiveSurveys() {
  const { data: activeSurveys, isLoading } = useQuery({
    queryKey: ['/api/bot-jobs/active'],
  });
  
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'in_progress':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'just_started':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'error':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status.toLowerCase()) {
      case 'in_progress':
        return 'In Progress';
      case 'just_started':
        return 'Just Started';
      default:
        return status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ');
    }
  };
  
  const getProgressBarColor = (status: string, progress: number) => {
    if (status.toLowerCase() === 'in_progress') return 'bg-primary';
    if (status.toLowerCase() === 'just_started') return 'bg-warning';
    if (status.toLowerCase() === 'error') return 'bg-destructive';
    return 'bg-primary';
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Active Surveys</CardTitle>
          <CardDescription>Loading active surveys...</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  const surveys = activeSurveys || [];
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Active Surveys</CardTitle>
          <CardDescription>Currently being processed by your bots</CardDescription>
        </div>
        <div className="flex space-x-2">
          <Button variant="ghost" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <SortAsc className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Survey</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Payout</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {surveys.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    No active surveys found
                  </TableCell>
                </TableRow>
              ) : (
                surveys.map((job) => (
                  <TableRow key={job.id}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-muted rounded-md flex items-center justify-center text-muted-foreground">
                          <ClipboardList className="h-5 w-5" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium">{job.survey?.name || 'Unknown Survey'}</div>
                          <div className="text-sm text-muted-foreground">
                            {job.survey?.estimatedDuration} minutes
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{job.survey?.provider?.name || 'Unknown Provider'}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">${parseFloat(job.survey?.payout || "0").toFixed(2)}</div>
                    </TableCell>
                    <TableCell>
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className={cn("h-2.5 rounded-full", getProgressBarColor(job.status, job.progress))} 
                          style={{ width: `${job.progress}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">{job.progress}% complete</div>
                    </TableCell>
                    <TableCell>
                      <Badge className={cn("font-normal", getStatusColor(job.status))}>
                        {getStatusLabel(job.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="link" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between border-t p-4">
        <div className="text-sm text-muted-foreground">
          Showing {surveys.length} of {surveys.length} active surveys
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" disabled>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" disabled>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
