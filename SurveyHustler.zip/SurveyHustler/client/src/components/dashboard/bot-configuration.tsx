import { useState, useEffect } from "react";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BotConfiguration() {
  const { toast } = useToast();
  const [delayRange, setDelayRange] = useState<number[]>([5, 15]);
  
  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/bot-settings'],
  });
  
  const [formState, setFormState] = useState({
    responseMinDelay: 5,
    responseMaxDelay: 15,
    enableTypos: true,
    enableVariation: true,
    enableConversational: true,
    minPayout: "0.50",
    maxDuration: "20"
  });
  
  // Update form when settings data loads
  useEffect(() => {
    if (settings) {
      setFormState({
        responseMinDelay: settings.responseMinDelay || 5,
        responseMaxDelay: settings.responseMaxDelay || 15,
        enableTypos: settings.enableTypos !== undefined ? settings.enableTypos : true,
        enableVariation: settings.enableVariation !== undefined ? settings.enableVariation : true,
        enableConversational: settings.enableConversational !== undefined ? settings.enableConversational : true,
        minPayout: settings.minPayout?.toString() || "0.50",
        maxDuration: settings.maxDuration?.toString() || "20"
      });
      setDelayRange([settings.responseMinDelay || 5, settings.responseMaxDelay || 15]);
    }
  }, [settings]);
  
  const handleSliderChange = (values: number[]) => {
    setDelayRange(values);
    setFormState(prev => ({
      ...prev,
      responseMinDelay: values[0],
      responseMaxDelay: values[1]
    }));
  };
  
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: typeof formState) => {
      return apiRequest('PUT', '/api/bot-settings', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
      toast({
        title: "Settings Updated",
        description: "Your bot settings have been successfully updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update settings: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettingsMutation.mutate(formState);
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Bot Configuration</CardTitle>
          <CardDescription>Loading bot settings...</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Bot Configuration</CardTitle>
        <CardDescription>Personalize your bot's behavior</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-medium mb-3">Response Timing</h4>
              <div className="bg-muted/50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Response Delay Range</span>
                  <span className="text-sm font-medium">
                    {delayRange[0]}-{delayRange[1]} seconds
                  </span>
                </div>
                <Slider 
                  value={delayRange}
                  max={30}
                  step={1}
                  onValueChange={handleSliderChange}
                  className="my-6"
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-muted-foreground">0s</span>
                  <span className="text-xs text-muted-foreground">30s</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium mb-3">Response Style</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enableTypos" className="font-medium">Typo Frequency</Label>
                    <p className="text-xs text-muted-foreground">Occasional typos for human-like responses</p>
                  </div>
                  <Switch 
                    id="enableTypos" 
                    checked={formState.enableTypos}
                    onCheckedChange={(checked) => setFormState(prev => ({ ...prev, enableTypos: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enableVariation" className="font-medium">Response Variation</Label>
                    <p className="text-xs text-muted-foreground">Vary response patterns to avoid detection</p>
                  </div>
                  <Switch 
                    id="enableVariation" 
                    checked={formState.enableVariation}
                    onCheckedChange={(checked) => setFormState(prev => ({ ...prev, enableVariation: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enableConversational" className="font-medium">Conversational Replies</Label>
                    <p className="text-xs text-muted-foreground">Add casual phrases to text responses</p>
                  </div>
                  <Switch 
                    id="enableConversational" 
                    checked={formState.enableConversational}
                    onCheckedChange={(checked) => setFormState(prev => ({ ...prev, enableConversational: checked }))}
                  />
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium mb-3">Survey Preferences</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="minPayout">Minimum Payout</Label>
                  <div className="relative mt-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-muted-foreground">$</span>
                    </div>
                    <Input 
                      id="minPayout"
                      className="pl-7"
                      value={formState.minPayout}
                      onChange={(e) => setFormState(prev => ({ ...prev, minPayout: e.target.value }))}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="maxDuration">Max Duration</Label>
                  <div className="relative mt-1">
                    <Input 
                      id="maxDuration"
                      className="pr-10"
                      value={formState.maxDuration}
                      onChange={(e) => setFormState(prev => ({ ...prev, maxDuration: e.target.value }))}
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                      <span className="text-muted-foreground">min</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={updateSettingsMutation.isPending}
              >
                {updateSettingsMutation.isPending ? "Saving..." : "Save Configuration"}
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
