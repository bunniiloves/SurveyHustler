import { useState } from "react";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { X, Plus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ProfileManager() {
  const { toast } = useToast();
  const [newInterest, setNewInterest] = useState("");
  
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/profile'],
  });
  
  const [formState, setFormState] = useState({
    fullName: "",
    age: "",
    gender: "",
    location: "",
    occupation: "",
    incomeRange: "",
    interests: [] as string[]
  });
  
  // Update form when profile data loads
  useState(() => {
    if (profile) {
      setFormState({
        fullName: profile.fullName || "",
        age: profile.age ? profile.age.toString() : "",
        gender: profile.gender || "",
        location: profile.location || "",
        occupation: profile.occupation || "",
        incomeRange: profile.incomeRange || "",
        interests: Array.isArray(profile.interests) ? [...profile.interests] : []
      });
    }
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof formState) => {
      return apiRequest('PUT', '/api/profile', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been successfully updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleInputChange = (field: string, value: string) => {
    setFormState((prev) => ({ ...prev, [field]: value }));
  };
  
  const addInterest = () => {
    if (newInterest.trim() && !formState.interests.includes(newInterest.trim())) {
      setFormState((prev) => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()]
      }));
      setNewInterest("");
    }
  };
  
  const removeInterest = (interest: string) => {
    setFormState((prev) => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(formState);
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Profile Manager</CardTitle>
          <CardDescription>Loading profile data...</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile Manager</CardTitle>
        <CardDescription>Configure your survey response profile</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="fullName">Full Name</Label>
              <Input 
                id="fullName"
                value={formState.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="age">Age</Label>
              <Input 
                id="age"
                type="number"
                value={formState.age}
                onChange={(e) => handleInputChange("age", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="gender">Gender</Label>
              <Select 
                value={formState.gender} 
                onValueChange={(value) => handleInputChange("gender", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Non-binary">Non-binary</SelectItem>
                  <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input 
                id="location"
                value={formState.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="occupation">Occupation</Label>
              <Input 
                id="occupation"
                value={formState.occupation}
                onChange={(e) => handleInputChange("occupation", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="incomeRange">Income Range</Label>
              <Select 
                value={formState.incomeRange} 
                onValueChange={(value) => handleInputChange("incomeRange", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select income range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="$0 - $25,000">$0 - $25,000</SelectItem>
                  <SelectItem value="$25,001 - $50,000">$25,001 - $50,000</SelectItem>
                  <SelectItem value="$50,001 - $75,000">$50,001 - $75,000</SelectItem>
                  <SelectItem value="$75,001 - $100,000">$75,001 - $100,000</SelectItem>
                  <SelectItem value="$100,001+">$100,001+</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mt-6">
            <Label>Interests (for targeted surveys)</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {formState.interests.map((interest) => (
                <span key={interest} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm flex items-center">
                  {interest}
                  <button 
                    type="button"
                    className="ml-1 text-primary/70 hover:text-primary focus:outline-none"
                    onClick={() => removeInterest(interest)}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
              <div className="flex items-center space-x-2">
                <Input 
                  value={newInterest}
                  onChange={(e) => setNewInterest(e.target.value)}
                  placeholder="Add interest"
                  className="h-8 w-32"
                />
                <Button 
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addInterest}
                >
                  <Plus className="h-3 w-3 mr-1" /> Add
                </Button>
              </div>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end">
            <Button 
              type="submit"
              disabled={updateProfileMutation.isPending}
            >
              {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
