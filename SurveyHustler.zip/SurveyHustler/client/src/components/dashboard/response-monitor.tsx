import { useState, useEffect, useRef } from "react";
import { Card, CardHeader, CardContent, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Pause, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

interface LogEntry {
  id: number;
  timestamp: string;
  botId: number;
  surveyName: string;
  action: string;
  response?: string;
  type?: string;
}

export default function ResponseMonitor() {
  const logContainerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  
  const { data: logs = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/survey-logs/recent'],
    refetchInterval: 10000 // Refresh every 10 seconds
  });
  
  // Auto-scroll to bottom when new logs come in
  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);
  
  const handleScroll = () => {
    if (logContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = logContainerRef.current;
      // Disable auto-scroll if user scrolls up manually
      setAutoScroll(scrollTop + clientHeight >= scrollHeight - 50);
    }
  };
  
  const formatTimestamp = (timestamp: string) => {
    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false
      });
    } catch (e) {
      return '00:00:00';
    }
  };
  
  const downloadLogs = () => {
    if (!logs || logs.length === 0) return;
    
    const content = logs.map(log => {
      return `[${formatTimestamp(log.timestamp)}] Bot #${log.botId} (${log.surveyName}): ${log.action}${log.response ? '\nResponse: ' + log.response : ''}`;
    }).join('\n\n');
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `survey_bot_logs_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const getLogIconColor = (type?: string) => {
    switch (type) {
      case 'answer':
        return 'text-green-600 dark:text-green-400';
      case 'start':
        return 'text-blue-600 dark:text-blue-400';
      case 'complete':
        return 'text-red-600 dark:text-red-400';
      case 'error':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Response Monitor</CardTitle>
          <CardDescription>Loading activity logs...</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Response Monitor</CardTitle>
        <CardDescription>Recent activity from your survey bots</CardDescription>
      </CardHeader>
      <CardContent>
        <div 
          ref={logContainerRef}
          onScroll={handleScroll}
          className="bg-muted/30 border border-border rounded-lg p-4 font-mono text-sm h-64 overflow-y-auto"
        >
          {logs.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No recent bot activity to display
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="bot-log-entry">
                <div className="flex items-start">
                  <span className={cn("log-timestamp", getLogIconColor(log.type))}>
                    [{formatTimestamp(log.timestamp)}]
                  </span>
                  <span>
                    Bot #{log.botId} ({log.surveyName}): {log.action}
                  </span>
                </div>
                {log.response && (
                  <div className="log-response">Response: {log.response}</div>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <Button variant="link" size="sm" className="px-0" onClick={downloadLogs}>
          <Download className="h-4 w-4 mr-1" /> Export Log
        </Button>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm">
            <Pause className="h-4 w-4 mr-1" /> Pause All Bots
          </Button>
          <Button size="sm" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-1" /> Refresh
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
