import { cn } from "@/lib/utils";
import { ArrowDown, ArrowUp } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  period?: string;
  changeValue?: number;
  progress?: number;
  progressColor?: string;
}

export default function StatCard({ 
  title, 
  value, 
  period = "Today", 
  changeValue, 
  progress, 
  progressColor = "bg-primary" 
}: StatCardProps) {
  const isPositiveChange = changeValue !== undefined ? changeValue > 0 : false;
  
  return (
    <div className="bg-card rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <h3 className="text-muted-foreground text-sm font-medium">{title}</h3>
        <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">{period}</span>
      </div>
      <div className="mt-2 flex items-baseline">
        <p className="text-3xl font-semibold text-card-foreground">{value}</p>
        {changeValue !== undefined && (
          <p className={cn(
            "ml-2 text-sm flex items-center",
            isPositiveChange ? "text-green-600" : "text-red-600"
          )}>
            {isPositiveChange ? (
              <ArrowUp className="w-3 h-3 mr-1" />
            ) : (
              <ArrowDown className="w-3 h-3 mr-1" />
            )}
            <span>{Math.abs(changeValue)}%</span>
          </p>
        )}
      </div>
      {progress !== undefined && (
        <div className="stats-progress-bar">
          <div className={cn(progressColor, "h-1 rounded-full")} style={{ width: `${progress}%` }}></div>
        </div>
      )}
    </div>
  );
}
