import { Menu } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface MobileHeaderProps {
  onToggleSidebar: () => void;
}

export default function MobileHeader({ onToggleSidebar }: MobileHeaderProps) {
  const { data: profile } = useQuery({
    queryKey: ['/api/profile'],
    retry: false,
    refetchOnWindowFocus: false
  });

  const initials = profile?.fullName
    ? profile.fullName.split(' ').map(n => n[0]).join('')
    : 'JS';

  return (
    <div className="md:hidden bg-white dark:bg-gray-800 w-full h-16 flex items-center justify-between px-4 border-b">
      <div className="flex items-center">
        <button 
          className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none mr-4"
          onClick={onToggleSidebar}
        >
          <Menu size={24} />
        </button>
        <div className="flex items-center">
          <div className="text-accent text-xl mr-2">🤖</div>
          <h1 className="text-lg font-semibold">SurveyBot</h1>
        </div>
      </div>
      <div className="flex items-center">
        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white">
          <span>{initials}</span>
        </div>
      </div>
    </div>
  );
}
