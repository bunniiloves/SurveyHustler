import { Link } from "wouter";
import { 
  BarChart2, ClipboardList, UserCircle, Settings, 
  Code, History, PieChart, LogOut, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

interface SidebarProps {
  currentPath: string;
  showMobile: boolean;
  onCloseMobile: () => void;
}

export default function Sidebar({ currentPath, showMobile, onCloseMobile }: SidebarProps) {
  const { data: profile } = useQuery({
    queryKey: ['/api/profile'],
    retry: false,
    refetchOnWindowFocus: false
  });

  const navItems = [
    { path: "/", label: "Dashboard", icon: <BarChart2 className="sidebar-icon" /> },
    { path: "/active-surveys", label: "Active Surveys", icon: <ClipboardList className="sidebar-icon" /> },
    { path: "/profile-manager", label: "Profile Manager", icon: <UserCircle className="sidebar-icon" /> },
    { path: "/bot-settings", label: "Bot Settings", icon: <Settings className="sidebar-icon" /> },
  ];

  const toolItems = [
    { path: "/response-templates", label: "Response Templates", icon: <Code className="sidebar-icon" /> },
    { path: "/survey-history", label: "Survey History", icon: <History className="sidebar-icon" /> },
    { path: "/earnings-report", label: "Earnings Report", icon: <PieChart className="sidebar-icon" /> },
  ];

  return (
    <aside 
      className={cn(
        "bg-sidebar-background text-sidebar-foreground w-64 flex-shrink-0 flex flex-col",
        "fixed inset-y-0 left-0 z-20 transform transition-transform duration-200 ease-in-out md:relative md:translate-x-0",
        showMobile ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}
    >
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-2">
          <div className="text-sidebar-accent text-xl">🤖</div>
          <div>
            <h1 className="text-xl font-semibold">SurveyBot</h1>
            <p className="text-sidebar-foreground/60 text-sm">Automated Survey Assistant</p>
          </div>
        </div>
        <button 
          className="md:hidden text-sidebar-foreground/60 hover:text-sidebar-foreground"
          onClick={onCloseMobile}
        >
          <X size={20} />
        </button>
      </div>
      
      <nav className="flex-1 overflow-y-auto">
        <div className="px-4 mb-2 text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider">
          Main
        </div>
        
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            onClick={() => { if (showMobile) onCloseMobile(); }}
          >
            <a className={cn("sidebar-item", { active: currentPath === item.path })}>
              {item.icon}
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
        
        <div className="px-4 mt-6 mb-2 text-xs font-semibold text-sidebar-foreground/60 uppercase tracking-wider">
          Tools
        </div>
        
        {toolItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            onClick={() => { if (showMobile) onCloseMobile(); }}
          >
            <a className={cn("sidebar-item", { active: currentPath === item.path })}>
              {item.icon}
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-sidebar-accent flex items-center justify-center mr-3">
            <span className="text-sidebar-accent-foreground font-medium">
              {profile?.fullName?.split(' ').map(n => n[0]).join('') || 'JS'}
            </span>
          </div>
          <div>
            <p className="text-sm font-medium">{profile?.fullName || 'John Smith'}</p>
            <p className="text-xs text-sidebar-foreground/60">{profile?.email || 'john@example.com'}</p>
          </div>
          <button className="ml-auto text-sidebar-foreground/60 hover:text-sidebar-foreground">
            <Settings size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
}
