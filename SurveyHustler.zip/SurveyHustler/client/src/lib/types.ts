// User Profile Types
export interface UserProfile {
  id: number;
  username: string;
  fullName: string;
  email: string;
  age?: number;
  gender?: string;
  location?: string;
  occupation?: string;
  incomeRange?: string;
  interests: string[];
  education?: string;
  maritalStatus?: string;
  bio?: string;
  phoneNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserProfileFormData {
  fullName: string;
  email: string;
  age?: string;
  gender?: string;
  location?: string;
  occupation?: string;
  incomeRange?: string;
  education?: string;
  maritalStatus?: string;
  interests: string[];
  bio?: string;
  phoneNumber?: string;
}

// Bot Settings Types
export interface BotSettings {
  id: number;
  profileId: number;
  responseMinDelay: number;
  responseMaxDelay: number;
  enableTypos: boolean;
  enableVariation: boolean;
  enableConversational: boolean;
  minPayout: string;
  maxDuration: number;
  typoFrequency?: string;
  sentenceVariation?: string;
  behaviorProfile?: string;
  maxConcurrentSurveys?: number;
  autoStartSurveys?: boolean;
  preferredSurveyTypes?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface BotSettingsFormData {
  responseMinDelay: number;
  responseMaxDelay: number;
  enableTypos: boolean;
  enableVariation: boolean;
  enableConversational: boolean;
  minPayout: string;
  maxDuration: string;
  typoFrequency?: string;
  sentenceVariation?: string;
  behaviorProfile?: string;
  maxConcurrentSurveys?: string;
  autoStartSurveys?: boolean;
  preferredSurveyTypes?: string[];
}

// Survey Provider Types
export interface SurveyProvider {
  id: number;
  name: string;
  url: string;
  apiKey?: string;
  active: boolean;
  createdAt: string;
}

// Survey Types
export interface Survey {
  id: number;
  providerId: number;
  provider: SurveyProvider;
  name: string;
  description?: string;
  externalId?: string;
  estimatedDuration: number;
  payout: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

// Bot Job Types
export interface BotJob {
  id: number;
  profileId: number;
  surveyId: number;
  survey: Survey;
  status: string;
  progress: number;
  startedAt: string;
  completedAt?: string;
  earnedAmount?: string;
  errorMessage?: string;
  createdAt: string;
  updatedAt: string;
}

// Response Template Types
export interface ResponseTemplate {
  id: number;
  profileId: number;
  category: string;
  content: string;
  createdAt: string;
}

export interface ResponseTemplateFormData {
  id: number | null;
  category: string;
  content: string;
}

// Survey Log Types
export interface SurveyLog {
  id: number;
  botJobId: number;
  questionText?: string;
  questionType: string;
  response?: string;
  timestamp: string;
}

// Statistics Types
export interface Statistic {
  id: number;
  profileId: number;
  date: string;
  completedSurveys: number;
  earnings: string;
  successRate: string;
  totalTime: number;
}

// Time Series Data for Charts
export interface TimeSeriesData {
  date: string;
  earnings: number;
  surveysCompleted: number;
  avgTimeMinutes?: number;
}

// Provider Breakdown for Charts
export interface ProviderBreakdown {
  providerId: number;
  providerName: string;
  earnings: number;
  count: number;
}

// Dashboard Stats
export interface DashboardStats {
  completedSurveys: number;
  earnings: string;
  successRate: string;
  activeBots: number;
}

// Earnings Report
export interface EarningsReport {
  totalEarnings: number;
  averagePerSurvey: number;
  completedSurveys: number;
  averageTimeMinutes: number;
  successRate: number;
  surveysPerDay: number;
  timeSeriesData: TimeSeriesData[];
  providerBreakdown: ProviderBreakdown[];
}

// Survey History Pagination
export interface SurveyHistoryResponse {
  jobs: BotJob[];
  total: number;
  page: number;
  pageSize: number;
  hasNextPage: boolean;
}

// Question Types
export enum QuestionType {
  MULTIPLE_CHOICE = "multiple_choice",
  MULTIPLE_SELECT = "multiple_select",
  TEXT = "text",
  RATING = "rating",
  SCALE = "scale",
  YES_NO = "yes_no",
  LIKERT = "likert",
  RANKING = "ranking",
}

// Survey Question for Bot Processing
export interface SurveyQuestion {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  required: boolean;
  minLength?: number;
  maxLength?: number;
  minValue?: number;
  maxValue?: number;
}

// Bot Response to Survey Question
export interface BotResponse {
  questionId: string;
  response: string | string[] | number;
  responseTime: number;
}
