import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Plus, 
  Filter, 
  RefreshCw, 
  Search,
  ClipboardList
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function ActiveSurveys() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [providerFilter, setProviderFilter] = useState("all");
  
  const { data: botJobs, isLoading, refetch } = useQuery({
    queryKey: ['/api/bot-jobs'],
  });
  
  const { data: providers } = useQuery({
    queryKey: ['/api/survey-providers'],
  });
  
  const filteredJobs = botJobs 
    ? botJobs.filter(job => {
        const matchesSearch = !searchQuery || 
          job.survey.name.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesStatus = statusFilter === "all" || 
          job.status.toLowerCase() === statusFilter.toLowerCase();
        
        const matchesProvider = providerFilter === "all" || 
          job.survey.providerId.toString() === providerFilter;
        
        return matchesSearch && matchesStatus && matchesProvider;
      })
    : [];
  
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'in_progress':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'just_started':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'error':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'pending':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };
  
  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleString();
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Active Surveys</h2>
          <p className="text-muted-foreground">Manage all your running survey bots</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button className="flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            <span>Add New Survey</span>
          </Button>
          <Button variant="outline" className="flex items-center" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            <span>Refresh</span>
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Search & Filter</CardTitle>
          <CardDescription>Find specific surveys or filter by status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search surveys..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="just_started">Just Started</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
            <Select value={providerFilter} onValueChange={setProviderFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by provider" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Providers</SelectItem>
                {providers?.map(provider => (
                  <SelectItem key={provider.id} value={provider.id.toString()}>
                    {provider.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Survey Jobs</CardTitle>
          <CardDescription>All survey jobs in your account</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-muted-foreground">Loading survey jobs...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Survey</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Payout</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredJobs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        No survey jobs match your filters
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredJobs.map(job => (
                      <TableRow key={job.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mr-3">
                              <ClipboardList className="w-5 h-5 text-muted-foreground" />
                            </div>
                            <div>
                              <div className="font-medium">{job.survey.name}</div>
                              <div className="text-sm text-muted-foreground">{job.survey.estimatedDuration} minutes</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{job.survey.provider.name}</TableCell>
                        <TableCell>{formatDate(job.startedAt)}</TableCell>
                        <TableCell>
                          <Badge className={cn("font-normal", getStatusColor(job.status))}>
                            {job.status.charAt(0).toUpperCase() + job.status.slice(1).replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="w-full bg-muted rounded-full h-2.5">
                            <div 
                              className="bg-primary h-2.5 rounded-full" 
                              style={{ width: `${job.progress}%` }}
                            ></div>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">{job.progress}%</div>
                        </TableCell>
                        <TableCell>${parseFloat(job.survey.payout).toFixed(2)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">View</Button>
                          {['in_progress', 'just_started'].includes(job.status.toLowerCase()) && (
                            <Button variant="ghost" size="sm" className="text-red-500">Stop</Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="border-t flex items-center justify-between p-4">
          <div className="text-sm text-muted-foreground">
            Showing {filteredJobs.length} of {botJobs?.length || 0} total jobs
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" disabled>Previous</Button>
            <Button variant="outline" size="sm" disabled>Next</Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
