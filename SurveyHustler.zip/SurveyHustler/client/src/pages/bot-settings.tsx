import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Save, 
  Settings as SettingsIcon, 
  Clock, 
  Bot, 
  DollarSign, 
  PenTool, 
  Sliders 
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function BotSettings() {
  const { toast } = useToast();
  const [delayRange, setDelayRange] = useState<number[]>([5, 15]);
  
  const { data: settings, isLoading } = useQuery({
    queryKey: ['/api/bot-settings'],
  });
  
  const [formData, setFormData] = useState({
    responseMinDelay: 5,
    responseMaxDelay: 15,
    enableTypos: true,
    enableVariation: true,
    enableConversational: true,
    minPayout: "0.50",
    maxDuration: "20",
    typoFrequency: "low",
    sentenceVariation: "medium",
    behaviorProfile: "casual",
    maxConcurrentSurveys: "3",
    autoStartSurveys: true,
    preferredSurveyTypes: ["consumer", "technology", "opinion"]
  });
  
  // Update form when settings data loads
  useEffect(() => {
    if (settings) {
      setFormData({
        responseMinDelay: settings.responseMinDelay || 5,
        responseMaxDelay: settings.responseMaxDelay || 15,
        enableTypos: settings.enableTypos !== undefined ? settings.enableTypos : true,
        enableVariation: settings.enableVariation !== undefined ? settings.enableVariation : true,
        enableConversational: settings.enableConversational !== undefined ? settings.enableConversational : true,
        minPayout: settings.minPayout?.toString() || "0.50",
        maxDuration: settings.maxDuration?.toString() || "20",
        typoFrequency: settings.typoFrequency || "low",
        sentenceVariation: settings.sentenceVariation || "medium",
        behaviorProfile: settings.behaviorProfile || "casual",
        maxConcurrentSurveys: settings.maxConcurrentSurveys?.toString() || "3",
        autoStartSurveys: settings.autoStartSurveys !== undefined ? settings.autoStartSurveys : true,
        preferredSurveyTypes: settings.preferredSurveyTypes || ["consumer", "technology", "opinion"]
      });
      setDelayRange([settings.responseMinDelay || 5, settings.responseMaxDelay || 15]);
    }
  }, [settings]);
  
  const handleSliderChange = (values: number[]) => {
    setDelayRange(values);
    setFormData(prev => ({
      ...prev,
      responseMinDelay: values[0],
      responseMaxDelay: values[1]
    }));
  };
  
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('PUT', '/api/bot-settings', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-settings'] });
      toast({
        title: "Settings Updated",
        description: "Your bot settings have been successfully updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: `Error updating settings: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettingsMutation.mutate(formData);
  };
  
  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="ml-2">Loading bot settings...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">Bot Settings</h2>
        <p className="text-muted-foreground">Configure the behavior of your automated survey bots</p>
      </div>
      
      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="timing" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-3 md:inline-flex">
            <TabsTrigger value="timing">Response Timing</TabsTrigger>
            <TabsTrigger value="behavior">Behavior</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
          </TabsList>
          
          <TabsContent value="timing" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Response Timing Settings</CardTitle>
                </div>
                <CardDescription>
                  Configure how your bot times its responses to appear more human-like
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="text-sm font-medium mb-3">Response Delay Range</h4>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Delay between actions</span>
                      <span className="text-sm font-medium">
                        {delayRange[0]}-{delayRange[1]} seconds
                      </span>
                    </div>
                    <Slider 
                      value={delayRange}
                      max={30}
                      step={1}
                      onValueChange={handleSliderChange}
                      className="my-6"
                    />
                    <div className="flex justify-between mt-1">
                      <span className="text-xs text-muted-foreground">0s (Fast)</span>
                      <span className="text-xs text-muted-foreground">30s (Slow)</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-3">
                      Setting a variable delay makes your bot appear more human-like. Too fast responses may trigger anti-bot detection.
                    </p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-3">Timing Variations</h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <Label className="font-medium">Longer delays for complex questions</Label>
                        <p className="text-xs text-muted-foreground mt-1">
                          Take more time on essay and long-form questions
                        </p>
                      </div>
                      <Switch 
                        checked={formData.enableVariation}
                        onCheckedChange={(checked) => handleChange("enableVariation", checked)}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="maxPauseTime">Maximum pause time (seconds)</Label>
                        <Input 
                          id="maxPauseTime"
                          type="number"
                          placeholder="60"
                          defaultValue="60"
                        />
                        <p className="text-xs text-muted-foreground">
                          Maximum time to pause between survey sections
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="characterTypingSpeed">Typing speed (chars/sec)</Label>
                        <Select defaultValue="medium">
                          <SelectTrigger id="characterTypingSpeed">
                            <SelectValue placeholder="Select typing speed" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="slow">Slow (1-2 chars/sec)</SelectItem>
                            <SelectItem value="medium">Medium (3-5 chars/sec)</SelectItem>
                            <SelectItem value="fast">Fast (6-10 chars/sec)</SelectItem>
                            <SelectItem value="varied">Varied (changes randomly)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="behavior" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Bot className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Bot Behavior Settings</CardTitle>
                </div>
                <CardDescription>
                  Configure how your bot responds to survey questions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="text-sm font-medium mb-3">Human-like Behavior</h4>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <Label className="font-medium">Occasional typos</Label>
                        <p className="text-xs text-muted-foreground mt-1">
                          Add realistic typing errors that humans make
                        </p>
                      </div>
                      <Switch 
                        checked={formData.enableTypos}
                        onCheckedChange={(checked) => handleChange("enableTypos", checked)}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <Label className="font-medium">Conversational style</Label>
                        <p className="text-xs text-muted-foreground mt-1">
                          Add casual phrases and conversational elements
                        </p>
                      </div>
                      <Switch 
                        checked={formData.enableConversational}
                        onCheckedChange={(checked) => handleChange("enableConversational", checked)}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="typoFrequency">Typo frequency</Label>
                        <Select 
                          id="typoFrequency"
                          value={formData.typoFrequency}
                          onValueChange={(value) => handleChange("typoFrequency", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="very_low">Very Low (1%)</SelectItem>
                            <SelectItem value="low">Low (2-3%)</SelectItem>
                            <SelectItem value="medium">Medium (4-5%)</SelectItem>
                            <SelectItem value="high">High (6-8%)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="sentenceVariation">Sentence variation</Label>
                        <Select 
                          id="sentenceVariation"
                          value={formData.sentenceVariation}
                          onValueChange={(value) => handleChange("sentenceVariation", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select variation level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low (Formal, direct)</SelectItem>
                            <SelectItem value="medium">Medium (Mix of styles)</SelectItem>
                            <SelectItem value="high">High (Varied, colloquial)</SelectItem>
                            <SelectItem value="adaptive">Adaptive (Context-based)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="behaviorProfile">Behavior profile</Label>
                        <Select 
                          id="behaviorProfile"
                          value={formData.behaviorProfile}
                          onValueChange={(value) => handleChange("behaviorProfile", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select profile" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="formal">Formal (Professional)</SelectItem>
                            <SelectItem value="casual">Casual (Everyday)</SelectItem>
                            <SelectItem value="enthusiastic">Enthusiastic (Excited)</SelectItem>
                            <SelectItem value="thoughtful">Thoughtful (Detailed)</SelectItem>
                            <SelectItem value="random">Random (Changes per survey)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="responseConsistency">Response consistency</Label>
                        <Select defaultValue="high">
                          <SelectTrigger id="responseConsistency">
                            <SelectValue placeholder="Select consistency level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low (Varies between surveys)</SelectItem>
                            <SelectItem value="medium">Medium (Some consistency)</SelectItem>
                            <SelectItem value="high">High (Mostly consistent)</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          How consistent your responses are across different surveys
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="preferences" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center">
                  <Sliders className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Survey Preferences</CardTitle>
                </div>
                <CardDescription>
                  Configure which surveys your bot accepts and completes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="text-sm font-medium mb-3">Survey Selection</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="minPayout">Minimum Payout</Label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <Input 
                          id="minPayout"
                          className="pl-8" 
                          value={formData.minPayout}
                          onChange={(e) => handleChange("minPayout", e.target.value)}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Only accept surveys that pay at least this amount
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="maxDuration">Maximum Duration (minutes)</Label>
                      <div className="relative">
                        <Input 
                          id="maxDuration"
                          className="pr-10"
                          value={formData.maxDuration}
                          onChange={(e) => handleChange("maxDuration", e.target.value)}
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                          <span className="text-muted-foreground">min</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Skip surveys longer than this duration
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="maxConcurrentSurveys">Maximum concurrent surveys</Label>
                      <Input 
                        id="maxConcurrentSurveys"
                        type="number"
                        value={formData.maxConcurrentSurveys}
                        onChange={(e) => handleChange("maxConcurrentSurveys", e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">
                        Maximum number of surveys to run at once
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <Label className="font-medium">Auto-start surveys</Label>
                        <Switch 
                          checked={formData.autoStartSurveys}
                          onCheckedChange={(checked) => handleChange("autoStartSurveys", checked)}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Automatically start new surveys when they become available
                      </p>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium mb-3">Schedule & Availability</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="activeHours">Active hours</Label>
                      <Select defaultValue="all">
                        <SelectTrigger id="activeHours">
                          <SelectValue placeholder="Select active hours" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">24/7 (All hours)</SelectItem>
                          <SelectItem value="business">Business hours (9am-5pm)</SelectItem>
                          <SelectItem value="evening">Evening hours (5pm-11pm)</SelectItem>
                          <SelectItem value="custom">Custom schedule</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="activeDays">Active days</Label>
                      <Select defaultValue="weekdays">
                        <SelectTrigger id="activeDays">
                          <SelectValue placeholder="Select active days" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All days</SelectItem>
                          <SelectItem value="weekdays">Weekdays only</SelectItem>
                          <SelectItem value="weekends">Weekends only</SelectItem>
                          <SelectItem value="custom">Custom days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <div className="mt-6 flex justify-end">
            <Button 
              type="submit" 
              className="flex items-center" 
              disabled={updateSettingsMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {updateSettingsMutation.isPending ? "Saving..." : "Save Settings"}
            </Button>
          </div>
        </Tabs>
      </form>
    </div>
  );
}
