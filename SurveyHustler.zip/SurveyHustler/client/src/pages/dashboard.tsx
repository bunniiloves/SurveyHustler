import { useQuery } from "@tanstack/react-query";
import { Plus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import StatCard from "@/components/dashboard/stat-card";
import ProfileManager from "@/components/dashboard/profile-manager";
import BotConfiguration from "@/components/dashboard/bot-configuration";
import ActiveSurveys from "@/components/dashboard/active-surveys";
import ResponseMonitor from "@/components/dashboard/response-monitor";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/statistics/today'],
  });
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">Dashboard</h2>
          <p className="text-muted-foreground">Monitor your survey bot performance and activity</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button className="flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            <span>Add Survey</span>
          </Button>
          <Button variant="outline" className="flex items-center">
            <RefreshCw className="w-4 h-4 mr-2" />
            <span>Refresh</span>
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Completed Surveys" 
          value={statsLoading ? "-" : stats?.completedSurveys || 0} 
          changeValue={7} 
          progress={75} 
          progressColor="bg-primary"
        />
        <StatCard 
          title="Earnings" 
          value={statsLoading ? "-" : `$${parseFloat(stats?.earnings || "0").toFixed(2)}`} 
          changeValue={12} 
          progress={65} 
          progressColor="bg-secondary"
        />
        <StatCard 
          title="Success Rate" 
          value={statsLoading ? "-" : `${parseFloat(stats?.successRate || "0").toFixed(0)}%`} 
          changeValue={3} 
          progress={92} 
          progressColor="bg-accent"
        />
        <StatCard 
          title="Active Bots" 
          value={statsLoading ? "-" : stats?.activeBots || 0} 
          changeValue={-1} 
          progress={60} 
          progressColor="bg-warning"
        />
      </div>
      
      {/* Profile Management and Bot Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <ProfileManager />
        <BotConfiguration />
      </div>
      
      {/* Active Surveys */}
      <div className="mb-8">
        <ActiveSurveys />
      </div>
      
      {/* Survey Output Monitoring */}
      <div>
        <ResponseMonitor />
      </div>
    </div>
  );
}
