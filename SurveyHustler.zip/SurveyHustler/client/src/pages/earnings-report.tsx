import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart, 
  Download, 
  RefreshCw, 
  DollarSign, 
  Calendar, 
  TrendingUp, 
  Clock,
  Calculator
} from "lucide-react";
import { format, subDays, startOfMonth, endOfMonth, startOfYear, endOfYear } from "date-fns";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DateRange } from "react-day-picker";
import { DateRangePicker } from "@/components/ui/date-range-picker";

// Import from recharts
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

// Component for custom tooltip
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover p-3 rounded-md shadow-md border border-border">
        <p className="font-medium">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {entry.name}: ${entry.value.toFixed(2)}
          </p>
        ))}
      </div>
    );
  }

  return null;
};

export default function EarningsReport() {
  // States for date range and period selection
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date())
  });
  
  const [periodView, setPeriodView] = useState("weekly");
  const [selectedTab, setSelectedTab] = useState("earnings");
  
  // Predefined periods
  const handlePeriodChange = (period: string) => {
    const today = new Date();
    
    switch (period) {
      case "7days":
        setDateRange({
          from: subDays(today, 7),
          to: today
        });
        break;
      case "30days":
        setDateRange({
          from: subDays(today, 30),
          to: today
        });
        break;
      case "thisMonth":
        setDateRange({
          from: startOfMonth(today),
          to: endOfMonth(today)
        });
        break;
      case "lastMonth":
        const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1);
        setDateRange({
          from: startOfMonth(lastMonth),
          to: endOfMonth(lastMonth)
        });
        break;
      case "thisYear":
        setDateRange({
          from: startOfYear(today),
          to: endOfYear(today)
        });
        break;
    }
  };
  
  // Format date range for display
  const formatDateRange = () => {
    if (!dateRange?.from) return "Select date range";
    
    let formattedRange = format(dateRange.from, "MMM d, yyyy");
    if (dateRange.to) {
      formattedRange += ` - ${format(dateRange.to, "MMM d, yyyy")}`;
    }
    
    return formattedRange;
  };
  
  // Fetch earnings data based on date range
  const { data: earningsData, isLoading, refetch } = useQuery({
    queryKey: ['/api/statistics/earnings', dateRange?.from, dateRange?.to, periodView],
  });
  
  // Calculate summary metrics
  const totalEarnings = earningsData?.totalEarnings || 0;
  const averagePerSurvey = earningsData?.averagePerSurvey || 0;
  const completedSurveys = earningsData?.completedSurveys || 0;
  const averageTimePerSurvey = earningsData?.averageTimeMinutes || 0;
  const hourlyRate = averageTimePerSurvey > 0 
    ? (averagePerSurvey / (averageTimePerSurvey / 60)) 
    : 0;
  
  // Prepare chart data
  const chartData = earningsData?.timeSeriesData || [];
  
  // Provider breakdown data
  const providerData = earningsData?.providerBreakdown || [];
  
  // Download report as CSV
  const downloadReport = () => {
    // Generate CSV content
    let csvContent = "date,earnings,surveys_completed\n";
    chartData.forEach((data: any) => {
      csvContent += `${data.date},${data.earnings},${data.surveysCompleted}\n`;
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `earnings_report_${format(new Date(), "yyyy-MM-dd")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Colors for pie chart
  const COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444', '#6B7280'];
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Earnings Report</h2>
          <p className="text-muted-foreground">Analyze your survey earnings and performance</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button variant="outline" className="flex items-center" onClick={downloadReport}>
            <Download className="w-4 h-4 mr-2" />
            <span>Export Report</span>
          </Button>
          <Button variant="outline" className="flex items-center" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            <span>Refresh</span>
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Time Period</CardTitle>
          <CardDescription>Select the date range for your report</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col space-y-1.5">
              <h3 className="text-sm font-medium">Date Range</h3>
              <DateRangePicker
                date={dateRange}
                onDateChange={setDateRange}
              />
            </div>
            
            <div className="flex flex-col space-y-1.5">
              <h3 className="text-sm font-medium">Quick Select</h3>
              <Select onValueChange={handlePeriodChange} defaultValue="thisMonth">
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 Days</SelectItem>
                  <SelectItem value="30days">Last 30 Days</SelectItem>
                  <SelectItem value="thisMonth">This Month</SelectItem>
                  <SelectItem value="lastMonth">Last Month</SelectItem>
                  <SelectItem value="thisYear">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex flex-col space-y-1.5">
              <h3 className="text-sm font-medium">Data Grouping</h3>
              <Select value={periodView} onValueChange={setPeriodView}>
                <SelectTrigger>
                  <SelectValue placeholder="Select view" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <DollarSign className="h-4 w-4 mr-1 text-primary" />
              Total Earnings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${totalEarnings.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">{formatDateRange()}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Calculator className="h-4 w-4 mr-1 text-primary" />
              Average per Survey
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${averagePerSurvey.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Per completed survey</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Clock className="h-4 w-4 mr-1 text-primary" />
              Hourly Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${hourlyRate.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">Estimated per hour</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Calendar className="h-4 w-4 mr-1 text-primary" />
              Surveys Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{completedSurveys}</div>
            <p className="text-xs text-muted-foreground mt-1">During selected period</p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="earnings">Earnings Chart</TabsTrigger>
          <TabsTrigger value="providers">Provider Breakdown</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="earnings" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Earnings Over Time</CardTitle>
              <CardDescription>
                Your earnings trend for the selected period
              </CardDescription>
            </CardHeader>
            <CardContent className="px-2">
              {isLoading ? (
                <div className="h-80 flex items-center justify-center">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : chartData.length === 0 ? (
                <div className="h-80 flex items-center justify-center">
                  <p className="text-muted-foreground">No earnings data available for the selected period</p>
                </div>
              ) : (
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      data={chartData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{ fontSize: 12 }} 
                        tickFormatter={(value) => {
                          // Format based on period view
                          return periodView === 'monthly' 
                            ? value.substring(0, 7) // YYYY-MM
                            : value.substring(5); // MM-DD or Week #
                        }}
                      />
                      <YAxis tickFormatter={(value) => `$${value}`} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar name="Earnings" dataKey="earnings" fill="var(--chart-1)" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="providers" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Earnings by Provider</CardTitle>
              <CardDescription>
                Breakdown of earnings by survey provider
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {isLoading ? (
                  <div className="h-80 flex items-center justify-center col-span-2">
                    <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : providerData.length === 0 ? (
                  <div className="h-80 flex items-center justify-center col-span-2">
                    <p className="text-muted-foreground">No provider data available for the selected period</p>
                  </div>
                ) : (
                  <>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={providerData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="earnings"
                            nameKey="providerName"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {providerData.map((entry: any, index: number) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip 
                            formatter={(value: any) => [`$${value.toFixed(2)}`, "Earnings"]}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Provider Details</h3>
                      <div className="space-y-3">
                        {providerData.map((provider: any, index: number) => (
                          <div key={provider.providerId} className="flex justify-between items-center">
                            <div className="flex items-center">
                              <div 
                                className="w-3 h-3 rounded-full mr-2" 
                                style={{ backgroundColor: COLORS[index % COLORS.length] }}
                              ></div>
                              <span>{provider.providerName}</span>
                            </div>
                            <div className="flex flex-col items-end">
                              <span className="font-medium">${provider.earnings.toFixed(2)}</span>
                              <span className="text-xs text-muted-foreground">{provider.count} surveys</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="performance" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>
                Analyze your survey completion performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Completion Time Trend</h3>
                  {isLoading ? (
                    <div className="h-80 flex items-center justify-center">
                      <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : chartData.length === 0 ? (
                    <div className="h-80 flex items-center justify-center">
                      <p className="text-muted-foreground">No data available</p>
                    </div>
                  ) : (
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={chartData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="date" 
                            tick={{ fontSize: 12 }} 
                            tickFormatter={(value) => {
                              return periodView === 'monthly' 
                                ? value.substring(0, 7) // YYYY-MM
                                : value.substring(5); // MM-DD or Week #
                            }}
                          />
                          <YAxis 
                            yAxisId="left"
                            tickFormatter={(value) => `${value} min`} 
                          />
                          <YAxis 
                            yAxisId="right" 
                            orientation="right" 
                            domain={[0, 'dataMax + 2']}
                          />
                          <Tooltip />
                          <Legend />
                          <Line
                            yAxisId="left"
                            type="monotone"
                            name="Avg Time (min)"
                            dataKey="avgTimeMinutes"
                            stroke="var(--chart-2)"
                            activeDot={{ r: 8 }}
                          />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            name="Surveys"
                            dataKey="surveysCompleted"
                            stroke="var(--chart-3)" 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Efficiency Metrics</h3>
                  
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Average Survey Duration</span>
                        <span className="text-sm">{averageTimePerSurvey.toFixed(1)} minutes</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className="bg-primary h-2.5 rounded-full" 
                          style={{ width: `${Math.min(100, (averageTimePerSurvey / 30) * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Hourly Earnings Rate</span>
                        <span className="text-sm">${hourlyRate.toFixed(2)}/hour</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className="bg-secondary h-2.5 rounded-full" 
                          style={{ width: `${Math.min(100, (hourlyRate / 20) * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Surveys Per Day</span>
                        <span className="text-sm">
                          {earningsData?.surveysPerDay ? earningsData.surveysPerDay.toFixed(1) : "0"}
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className="bg-accent h-2.5 rounded-full" 
                          style={{ width: `${Math.min(100, ((earningsData?.surveysPerDay || 0) / 10) * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Success Rate</span>
                        <span className="text-sm">
                          {earningsData?.successRate ? earningsData.successRate.toFixed(0) : "0"}%
                        </span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className="bg-chart-4 h-2.5 rounded-full" 
                          style={{ width: `${earningsData?.successRate || 0}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
