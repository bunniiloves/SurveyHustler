import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  User, 
  MapPin, 
  Briefcase, 
  Calendar, 
  Mail, 
  Phone, 
  Tag,
  XCircle,
  PlusCircle,
  Save
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ProfileManager() {
  const { toast } = useToast();
  const [newInterest, setNewInterest] = useState("");
  
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/profile'],
  });
  
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    age: "",
    gender: "",
    location: "",
    occupation: "",
    incomeRange: "",
    education: "",
    maritalStatus: "",
    interests: [] as string[],
    bio: "",
    phoneNumber: ""
  });
  
  // Update form when profile data loads
  useState(() => {
    if (profile) {
      setFormData({
        fullName: profile.fullName || "",
        email: profile.email || "",
        age: profile.age ? profile.age.toString() : "",
        gender: profile.gender || "",
        location: profile.location || "",
        occupation: profile.occupation || "",
        incomeRange: profile.incomeRange || "",
        education: profile.education || "",
        maritalStatus: profile.maritalStatus || "",
        interests: Array.isArray(profile.interests) ? [...profile.interests] : [],
        bio: profile.bio || "",
        phoneNumber: profile.phoneNumber || ""
      });
    }
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('PUT', '/api/profile', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your profile information has been successfully updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: `Error updating profile: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const addInterest = () => {
    if (newInterest.trim() && !formData.interests.includes(newInterest.trim())) {
      setFormData(prev => ({
        ...prev,
        interests: [...prev.interests, newInterest.trim()]
      }));
      setNewInterest("");
    }
  };
  
  const removeInterest = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.filter(i => i !== interest)
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };
  
  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="ml-2">Loading profile data...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">Profile Manager</h2>
        <p className="text-muted-foreground">Configure your survey response profile details</p>
      </div>
      
      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-2 md:inline-flex">
            <TabsTrigger value="personal">Personal Information</TabsTrigger>
            <TabsTrigger value="demographic">Demographic Details</TabsTrigger>
          </TabsList>
          
          <TabsContent value="personal" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Details</CardTitle>
                <CardDescription>
                  This information will be used to personalize survey responses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">
                      <User className="h-4 w-4 inline mr-1" /> Full Name
                    </Label>
                    <Input 
                      id="fullName" 
                      value={formData.fullName}
                      onChange={(e) => handleInputChange("fullName", e.target.value)}
                      placeholder="John Smith"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">
                      <Mail className="h-4 w-4 inline mr-1" /> Email
                    </Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="john@example.com"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber">
                      <Phone className="h-4 w-4 inline mr-1" /> Phone Number
                    </Label>
                    <Input 
                      id="phoneNumber" 
                      value={formData.phoneNumber}
                      onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
                      placeholder="(123) 456-7890"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="age">
                      <Calendar className="h-4 w-4 inline mr-1" /> Age
                    </Label>
                    <Input 
                      id="age" 
                      type="number" 
                      value={formData.age}
                      onChange={(e) => handleInputChange("age", e.target.value)}
                      placeholder="32"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="location">
                      <MapPin className="h-4 w-4 inline mr-1" /> Location
                    </Label>
                    <Input 
                      id="location" 
                      value={formData.location}
                      onChange={(e) => handleInputChange("location", e.target.value)}
                      placeholder="New York, NY"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="occupation">
                      <Briefcase className="h-4 w-4 inline mr-1" /> Occupation
                    </Label>
                    <Input 
                      id="occupation" 
                      value={formData.occupation}
                      onChange={(e) => handleInputChange("occupation", e.target.value)}
                      placeholder="Software Developer"
                    />
                  </div>
                  
                  <div className="md:col-span-2 space-y-2">
                    <Label htmlFor="bio">Bio / About Me</Label>
                    <Textarea 
                      id="bio" 
                      value={formData.bio}
                      onChange={(e) => handleInputChange("bio", e.target.value)}
                      placeholder="Write a short bio that will help personalize your survey responses..."
                      className="min-h-[120px]"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="demographic" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Demographic Information</CardTitle>
                <CardDescription>
                  These details help qualify you for appropriate surveys
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <Select 
                      value={formData.gender} 
                      onValueChange={(value) => handleInputChange("gender", value)}
                    >
                      <SelectTrigger id="gender">
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Male">Male</SelectItem>
                        <SelectItem value="Female">Female</SelectItem>
                        <SelectItem value="Non-binary">Non-binary</SelectItem>
                        <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maritalStatus">Marital Status</Label>
                    <Select 
                      value={formData.maritalStatus} 
                      onValueChange={(value) => handleInputChange("maritalStatus", value)}
                    >
                      <SelectTrigger id="maritalStatus">
                        <SelectValue placeholder="Select marital status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Single">Single</SelectItem>
                        <SelectItem value="Married">Married</SelectItem>
                        <SelectItem value="Divorced">Divorced</SelectItem>
                        <SelectItem value="Widowed">Widowed</SelectItem>
                        <SelectItem value="Separated">Separated</SelectItem>
                        <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="education">Education Level</Label>
                    <Select 
                      value={formData.education} 
                      onValueChange={(value) => handleInputChange("education", value)}
                    >
                      <SelectTrigger id="education">
                        <SelectValue placeholder="Select education level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="High School">High School</SelectItem>
                        <SelectItem value="Some College">Some College</SelectItem>
                        <SelectItem value="Associate's Degree">Associate's Degree</SelectItem>
                        <SelectItem value="Bachelor's Degree">Bachelor's Degree</SelectItem>
                        <SelectItem value="Master's Degree">Master's Degree</SelectItem>
                        <SelectItem value="Doctorate">Doctorate</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="incomeRange">Income Range</Label>
                    <Select 
                      value={formData.incomeRange} 
                      onValueChange={(value) => handleInputChange("incomeRange", value)}
                    >
                      <SelectTrigger id="incomeRange">
                        <SelectValue placeholder="Select income range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="$0 - $25,000">$0 - $25,000</SelectItem>
                        <SelectItem value="$25,001 - $50,000">$25,001 - $50,000</SelectItem>
                        <SelectItem value="$50,001 - $75,000">$50,001 - $75,000</SelectItem>
                        <SelectItem value="$75,001 - $100,000">$75,001 - $100,000</SelectItem>
                        <SelectItem value="$100,001+">$100,001+</SelectItem>
                        <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="md:col-span-2 space-y-2">
                    <Label htmlFor="interests">
                      <Tag className="h-4 w-4 inline mr-1" /> Interests (for targeted surveys)
                    </Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.interests.map((interest) => (
                        <span key={interest} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm flex items-center">
                          {interest}
                          <button 
                            type="button"
                            className="ml-1 text-primary/70 hover:text-primary focus:outline-none"
                            onClick={() => removeInterest(interest)}
                          >
                            <XCircle className="h-3 w-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                    <div className="flex mt-2">
                      <Input 
                        value={newInterest}
                        onChange={(e) => setNewInterest(e.target.value)}
                        placeholder="Add a new interest..."
                        className="rounded-r-none"
                      />
                      <Button 
                        type="button" 
                        variant="secondary" 
                        className="rounded-l-none" 
                        onClick={addInterest}
                      >
                        <PlusCircle className="h-4 w-4 mr-1" /> Add
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Examples: Technology, Travel, Food & Dining, Fitness, Finance, Movies, Music, etc.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <div className="mt-6 flex justify-end">
            <Button 
              type="submit" 
              className="flex items-center" 
              disabled={updateProfileMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {updateProfileMutation.isPending ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </Tabs>
      </form>
    </div>
  );
}
