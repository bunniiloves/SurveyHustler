import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, 
  Plus, 
  Save, 
  Trash2, 
  ChevronRight, 
  ChevronLeft,
  Search,
  RefreshCw
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ResponseTemplates() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isAddTemplateOpen, setIsAddTemplateOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  
  const [formData, setFormData] = useState({
    id: null as number | null,
    category: "",
    content: ""
  });
  
  const { data: templates, isLoading, refetch } = useQuery({
    queryKey: ['/api/response-templates'],
  });
  
  const { data: categories } = useQuery({
    queryKey: ['/api/response-templates/categories'],
  });
  
  const saveTemplateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (data.id) {
        return apiRequest('PUT', `/api/response-templates/${data.id}`, data);
      } else {
        return apiRequest('POST', '/api/response-templates', data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/response-templates'] });
      setIsAddTemplateOpen(false);
      setFormData({ id: null, category: "", content: "" });
      toast({
        title: formData.id ? "Template Updated" : "Template Added",
        description: formData.id ? "Your response template has been updated." : "Your new response template has been added."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save template: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const deleteTemplateMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/response-templates/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/response-templates'] });
      toast({
        title: "Template Deleted",
        description: "Your response template has been deleted."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete template: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleAddNew = () => {
    setFormData({ id: null, category: "", content: "" });
    setIsAddTemplateOpen(true);
  };
  
  const handleEdit = (template: any) => {
    setFormData({
      id: template.id,
      category: template.category,
      content: template.content
    });
    setIsAddTemplateOpen(true);
  };
  
  const handleDelete = (id: number) => {
    deleteTemplateMutation.mutate(id);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category || !formData.content) {
      toast({
        title: "Validation Error",
        description: "Category and content are required.",
        variant: "destructive"
      });
      return;
    }
    saveTemplateMutation.mutate(formData);
  };
  
  const filteredTemplates = templates
    ? templates.filter(template => {
        const matchesSearch = !searchTerm || 
          template.content.toLowerCase().includes(searchTerm.toLowerCase()) || 
          template.category.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesCategory = selectedCategory === "all" || 
          template.category === selectedCategory;
        
        return matchesSearch && matchesCategory;
      })
    : [];
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Response Templates</h2>
          <p className="text-muted-foreground">Manage pre-defined responses for various survey questions</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button onClick={handleAddNew} className="flex items-center">
            <Plus className="w-4 h-4 mr-2" />
            <span>Add Template</span>
          </Button>
          <Button variant="outline" className="flex items-center" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            <span>Refresh</span>
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Search & Filter</CardTitle>
          <CardDescription>Find specific response templates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search templates..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories?.map((category: string) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <Code className="h-5 w-5 mr-2 text-primary" />
            <CardTitle>Response Templates</CardTitle>
          </div>
          <CardDescription>
            Custom responses used by your bot to answer survey questions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-muted-foreground">Loading templates...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead className="w-[50%]">Content</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTemplates.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                        No templates found. Create your first template to get started.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredTemplates.map(template => (
                      <TableRow key={template.id}>
                        <TableCell>
                          <span className="font-medium">{template.category}</span>
                        </TableCell>
                        <TableCell className="max-w-md">
                          <p className="truncate text-sm">{template.content}</p>
                        </TableCell>
                        <TableCell>
                          {new Date(template.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleEdit(template)}
                          >
                            Edit
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-red-500"
                              >
                                Delete
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Template</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this template? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  className="bg-red-500 hover:bg-red-600"
                                  onClick={() => handleDelete(template.id)}
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="border-t flex items-center justify-between p-4">
          <div className="text-sm text-muted-foreground">
            Showing {filteredTemplates.length} of {templates?.length || 0} templates
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" /> Previous
            </Button>
            <Button variant="outline" size="sm" disabled>
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardFooter>
      </Card>
      
      <Dialog open={isAddTemplateOpen} onOpenChange={setIsAddTemplateOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{formData.id ? "Edit Template" : "Add Template"}</DialogTitle>
            <DialogDescription>
              {formData.id 
                ? "Update your existing response template" 
                : "Create a new response template for your survey bot"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Input
                  id="category"
                  placeholder="E.g., Shopping, Technology, Finance"
                  value={formData.category}
                  onChange={(e) => handleInputChange("category", e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Categorize your template to easily find it later
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">Response Content</Label>
                <Textarea
                  id="content"
                  placeholder="Enter your template response here..."
                  className="min-h-[200px]"
                  value={formData.content}
                  onChange={(e) => handleInputChange("content", e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Write a detailed, human-like response that will be used for survey questions
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsAddTemplateOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={saveTemplateMutation.isPending}
              >
                <Save className="h-4 w-4 mr-2" />
                {saveTemplateMutation.isPending ? "Saving..." : "Save Template"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
