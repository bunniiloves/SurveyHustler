import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Calendar, 
  Search, 
  FileText, 
  ChevronLeft, 
  ChevronRight, 
  RefreshCw,
  Clock,
  DollarSign,
  CheckCircle,
  XCircle,
  Download,
  Eye
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { DateRange } from "react-day-picker";
import { format } from "date-fns";

export default function SurveyHistory() {
  // Date range selection for filtering
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(new Date().setDate(new Date().getDate() - 30)),
    to: new Date()
  });
  
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [providerFilter, setProviderFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  
  // Fetch survey history data
  const { data: surveyHistory, isLoading, refetch } = useQuery({
    queryKey: ['/api/bot-jobs/history', currentPage, dateRange, statusFilter, providerFilter],
  });
  
  const { data: providers } = useQuery({
    queryKey: ['/api/survey-providers'],
  });
  
  // Filter survey history based on search term
  const filteredHistory = surveyHistory?.jobs
    ? surveyHistory.jobs.filter(job => {
        const matchesSearch = !searchTerm || 
          job.survey.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          job.survey.provider.name.toLowerCase().includes(searchTerm.toLowerCase());
        
        return matchesSearch;
      })
    : [];
    
  // Status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'error':
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'disqualified':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };
  
  // Format duration in minutes
  const formatDuration = (startedAt: string, completedAt: string | null) => {
    if (!completedAt) return "In progress";
    
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    const durationMs = end - start;
    const minutes = Math.round(durationMs / (1000 * 60));
    
    return `${minutes} min${minutes !== 1 ? "s" : ""}`;
  };
  
  // Calculate total earnings from completed surveys
  const totalEarnings = filteredHistory
    .filter(job => job.status.toLowerCase() === 'completed' && job.earnedAmount)
    .reduce((sum, job) => sum + parseFloat(job.earnedAmount), 0);
  
  // Download survey history report
  const downloadReport = () => {
    // Generate CSV content
    const headers = ["Survey Name", "Provider", "Status", "Started", "Completed", "Duration", "Earned"];
    const rows = filteredHistory.map(job => [
      job.survey.name,
      job.survey.provider.name,
      job.status,
      formatDate(job.startedAt),
      job.completedAt ? formatDate(job.completedAt) : "N/A",
      formatDuration(job.startedAt, job.completedAt),
      job.earnedAmount ? `$${parseFloat(job.earnedAmount).toFixed(2)}` : "$0.00"
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.join(","))
    ].join("\n");
    
    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `survey_history_${format(new Date(), "yyyy-MM-dd")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Survey History</h2>
          <p className="text-muted-foreground">View and analyze your past surveys</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button variant="outline" className="flex items-center" onClick={downloadReport}>
            <Download className="w-4 h-4 mr-2" />
            <span>Export Report</span>
          </Button>
          <Button variant="outline" className="flex items-center" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            <span>Refresh</span>
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Surveys</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <FileText className="h-5 w-5 text-primary mr-2" />
              <span className="text-3xl font-bold">{filteredHistory.length}</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              <span className="text-3xl font-bold">
                {filteredHistory.length > 0 
                  ? `${Math.round((filteredHistory.filter(j => j.status.toLowerCase() === 'completed').length / filteredHistory.length) * 100)}%` 
                  : "0%"}
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <DollarSign className="h-5 w-5 text-green-500 mr-2" />
              <span className="text-3xl font-bold">${totalEarnings.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <CardTitle>Search & Filter</CardTitle>
          <CardDescription>Find specific survey history entries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search surveys..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <DateRangePicker 
              date={dateRange} 
              onDateChange={setDateRange} 
            />
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="error">Error/Failed</SelectItem>
                <SelectItem value="disqualified">Disqualified</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={providerFilter} onValueChange={setProviderFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by provider" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Providers</SelectItem>
                {providers?.map((provider: any) => (
                  <SelectItem key={provider.id} value={provider.id.toString()}>
                    {provider.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-primary" />
            <CardTitle>Survey History</CardTitle>
          </div>
          <CardDescription>
            History of surveys completed by your bots
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-muted-foreground">Loading survey history...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Survey</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Earned</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                        No survey history found. Complete some surveys to see your history.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredHistory.map(job => (
                      <TableRow key={job.id}>
                        <TableCell>
                          <div className="font-medium">{job.survey.name}</div>
                          <div className="text-xs text-muted-foreground">{job.survey.externalId || "No ID"}</div>
                        </TableCell>
                        <TableCell>{job.survey.provider.name}</TableCell>
                        <TableCell>
                          <Badge className={cn("font-normal", getStatusColor(job.status))}>
                            {job.status.charAt(0).toUpperCase() + job.status.slice(1).replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{formatDate(job.startedAt)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Clock className="h-3.5 w-3.5 mr-1 text-muted-foreground" />
                            <span>{formatDuration(job.startedAt, job.completedAt)}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {job.status.toLowerCase() === 'completed' && job.earnedAmount
                            ? <span className="text-green-600 font-medium">${parseFloat(job.earnedAmount).toFixed(2)}</span>
                            : <span className="text-muted-foreground">$0.00</span>
                          }
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4 mr-1" /> Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="border-t flex items-center justify-between p-4">
          <div className="text-sm text-muted-foreground">
            Showing {filteredHistory.length} of {surveyHistory?.total || 0} entries
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            >
              <ChevronLeft className="h-4 w-4 mr-1" /> Previous
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              disabled={!surveyHistory?.hasNextPage}
              onClick={() => setCurrentPage(prev => prev + 1)}
            >
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
