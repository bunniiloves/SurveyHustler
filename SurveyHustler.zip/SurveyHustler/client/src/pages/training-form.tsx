import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Brain, 
  Save, 
  Sparkles, 
  ArrowRight, 
  HelpCircle, 
  AlertCircle
} from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

const MAX_RESPONSE_LENGTH = 500;

// Define common survey question categories
const QUESTION_CATEGORIES = [
  "demographics",
  "shopping_habits",
  "tech_usage",
  "entertainment",
  "health",
  "finance",
  "travel",
  "food_preferences",
  "housing",
  "employment"
];

// Schema for the form
const trainingFormSchema = z.object({
  demographic_age: z.string().min(1, "Please provide your age"),
  demographic_occupation: z.string().min(1, "Please provide your occupation"),
  demographic_education: z.string().min(1, "Please provide your education level"),
  demographic_income: z.string().min(1, "Please provide your income range"),
  demographic_location: z.string().min(1, "Please provide your location"),
  
  shopping_online_frequency: z.string().min(1, "Please select an option"),
  shopping_preferences: z.string().min(10, "Please provide more details"),
  shopping_budget: z.string().min(1, "Please select an option"),
  
  tech_devices_owned: z.string().min(1, "Please provide your devices"),
  tech_social_media: z.string().min(1, "Please provide your social media usage"),
  tech_internet_hours: z.string().min(1, "Please select an option"),
  tech_preferences: z.string().min(10, "Please provide more details"),
  
  entertainment_streaming: z.string().min(1, "Please provide your streaming services"),
  entertainment_genres: z.string().min(1, "Please provide your favorite genres"),
  entertainment_free_time: z.string().min(10, "Please provide more details"),
  
  health_exercise: z.string().min(1, "Please select an option"),
  health_diet: z.string().min(10, "Please provide more details"),
  health_sleep: z.string().min(1, "Please select an option"),
  
  finance_investments: z.string().min(10, "Please provide more details"),
  finance_spending: z.string().min(10, "Please provide more details"),
  finance_goals: z.string().min(10, "Please provide more details"),
  
  travel_frequency: z.string().min(1, "Please select an option"),
  travel_preferences: z.string().min(10, "Please provide more details"),
  travel_destinations: z.string().min(10, "Please provide your favorite destinations"),
  
  food_diet: z.string().min(1, "Please select an option"),
  food_dining_out: z.string().min(1, "Please select an option"),
  food_preferences: z.string().min(10, "Please provide more details"),
  
  opinions_environment: z.string().min(10, "Please provide more details"),
  opinions_technology: z.string().min(10, "Please provide more details"),
  opinions_politics: z.string().min(10, "Please provide more details")
});

type TrainingFormValues = z.infer<typeof trainingFormSchema>;

export default function TrainingForm() {
  const [activeSection, setActiveSection] = useState<string>("demographics");
  const { toast } = useToast();
  
  // Initialize form with default values
  const form = useForm<TrainingFormValues>({
    resolver: zodResolver(trainingFormSchema),
    defaultValues: {
      demographic_age: "",
      demographic_occupation: "",
      demographic_education: "",
      demographic_income: "",
      demographic_location: "",
      
      shopping_online_frequency: "",
      shopping_preferences: "",
      shopping_budget: "",
      
      tech_devices_owned: "",
      tech_social_media: "",
      tech_internet_hours: "",
      tech_preferences: "",
      
      entertainment_streaming: "",
      entertainment_genres: "",
      entertainment_free_time: "",
      
      health_exercise: "",
      health_diet: "",
      health_sleep: "",
      
      finance_investments: "",
      finance_spending: "",
      finance_goals: "",
      
      travel_frequency: "",
      travel_preferences: "",
      travel_destinations: "",
      
      food_diet: "",
      food_dining_out: "",
      food_preferences: "",
      
      opinions_environment: "",
      opinions_technology: "",
      opinions_politics: "",
    }
  });
  
  // Load existing templates for the categories if available
  const { data: existingTemplates, isLoading: templatesLoading } = useQuery({
    queryKey: ['/api/response-templates'],
  });
  
  // Function to find an existing template with the given category
  const findExistingTemplate = (category: string) => {
    if (!existingTemplates || !Array.isArray(existingTemplates)) return null;
    return existingTemplates.find((template: any) => template.category === category);
  };
  
  // Mutation for saving templates
  const saveTemplateMutation = useMutation({
    mutationFn: async ({ category, content }: { category: string, content: string }) => {
      const existingTemplate = findExistingTemplate(category);
      
      if (existingTemplate) {
        // Update existing template
        return apiRequest(
          'PUT',
          `/api/response-templates/${existingTemplate.id}`, 
          { category, content }
        );
      } else {
        // Create new template
        return apiRequest(
          'POST', 
          '/api/response-templates', 
          { category, content }
        );
      }
    },
    onSuccess: () => {
      // Invalidate the templates query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/response-templates'] });
      toast({
        title: "Response saved",
        description: "Your personalized response has been saved and will be used for future surveys.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error saving response",
        description: error.message || "There was an error saving your response. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Save a single response template
  const saveTemplate = (category: string, value: string) => {
    saveTemplateMutation.mutate({ category, content: value });
  };
  
  // Submit handler
  const onSubmit = async (values: TrainingFormValues) => {
    // Process all form values and convert them to templates
    // Create/update templates for each category
    // For simplicity, we'll just show a success message
    toast({
      title: "Training data saved",
      description: "Your personalized responses have been saved and will be used to train the survey bot.",
    });
  };
  
  // Counter to track character limit for textarea inputs
  const countCharacters = (value: string) => {
    return `${value.length}/${MAX_RESPONSE_LENGTH}`;
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Survey Training Form</h2>
          <p className="text-muted-foreground">
            Teach the bot how to respond like you by answering common survey questions
          </p>
        </div>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center">
            <Brain className="h-5 w-5 mr-2 text-primary" />
            <CardTitle>How This Works</CardTitle>
          </div>
          <CardDescription>
            The more information you provide, the better the bot can mimic your response patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start">
              <Sparkles className="h-5 w-5 mr-3 text-primary mt-0.5" />
              <div>
                <h3 className="font-medium">Personalized Responses</h3>
                <p className="text-sm text-muted-foreground">
                  Your answers will be used to generate human-like responses to survey questions that match your preferences and style.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Save className="h-5 w-5 mr-3 text-primary mt-0.5" />
              <div>
                <h3 className="font-medium">Save Individual Answers</h3>
                <p className="text-sm text-muted-foreground">
                  Click the "Save This Response" button next to any question to store it as a template for similar questions in the future.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <AlertCircle className="h-5 w-5 mr-3 text-primary mt-0.5" />
              <div>
                <h3 className="font-medium">Privacy Note</h3>
                <p className="text-sm text-muted-foreground">
                  All information is stored securely and only used for generating responses. Use pseudonyms if you prefer.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Accordion 
            type="single" 
            collapsible 
            defaultValue="demographics"
            value={activeSection}
            onValueChange={(value) => setActiveSection(value)}
          >
            {/* Demographics Section */}
            <AccordionItem value="demographics">
              <AccordionTrigger className="text-lg font-medium">
                Demographics
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="demographic_age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center">
                          Age Range
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-4 w-4 ml-1">
                                  <HelpCircle className="h-3 w-3" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="w-72">
                                  Used for age-appropriate responses in demographic questions.
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select age range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="18-24">18-24 years</SelectItem>
                            <SelectItem value="25-34">25-34 years</SelectItem>
                            <SelectItem value="35-44">35-44 years</SelectItem>
                            <SelectItem value="45-54">45-54 years</SelectItem>
                            <SelectItem value="55-64">55-64 years</SelectItem>
                            <SelectItem value="65+">65+ years</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("demographic_age", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="demographic_occupation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center">
                          Occupation
                        </FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g. Software Developer, Teacher, etc." />
                        </FormControl>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("demographic_occupation", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="demographic_education"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Education Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select education level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="high_school">High School</SelectItem>
                            <SelectItem value="some_college">Some College</SelectItem>
                            <SelectItem value="associates">Associate's Degree</SelectItem>
                            <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                            <SelectItem value="masters">Master's Degree</SelectItem>
                            <SelectItem value="doctorate">Doctorate or Professional Degree</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("demographic_education", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="demographic_income"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Income Range</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select income range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="under_25k">Under $25,000</SelectItem>
                            <SelectItem value="25k_50k">$25,000 - $49,999</SelectItem>
                            <SelectItem value="50k_75k">$50,000 - $74,999</SelectItem>
                            <SelectItem value="75k_100k">$75,000 - $99,999</SelectItem>
                            <SelectItem value="100k_150k">$100,000 - $149,999</SelectItem>
                            <SelectItem value="over_150k">$150,000+</SelectItem>
                            <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("demographic_income", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="demographic_location"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g. New York, USA" />
                        </FormControl>
                        <FormDescription>
                          You can be as specific or vague as you prefer (country, city, region)
                        </FormDescription>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("demographic_location", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button 
                  type="button" 
                  onClick={() => setActiveSection("shopping")}
                  className="w-full mt-4"
                >
                  Next Section <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </AccordionContent>
            </AccordionItem>
            
            {/* Shopping Habits Section */}
            <AccordionItem value="shopping">
              <AccordionTrigger className="text-lg font-medium">
                Shopping Habits
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="shopping_online_frequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How often do you shop online?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="several_times_week">Several times a week</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="several_times_month">Several times a month</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="rarely">Rarely</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("shopping_online_frequency", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="shopping_budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How much do you typically spend on non-essential items monthly?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select budget range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="under_50">Under $50</SelectItem>
                            <SelectItem value="50_100">$50 - $100</SelectItem>
                            <SelectItem value="100_200">$100 - $200</SelectItem>
                            <SelectItem value="200_500">$200 - $500</SelectItem>
                            <SelectItem value="over_500">Over $500</SelectItem>
                            <SelectItem value="variable">It varies significantly</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("shopping_budget", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="shopping_preferences"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>
                          What factors influence your purchasing decisions? (price, quality, brand, reviews, etc.)
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Describe your shopping preferences and priorities..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("shopping_preferences", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between mt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveSection("demographics")}
                  >
                    Previous Section
                  </Button>
                  <Button 
                    type="button"
                    onClick={() => setActiveSection("technology")}
                  >
                    Next Section <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Technology Usage Section */}
            <AccordionItem value="technology">
              <AccordionTrigger className="text-lg font-medium">
                Technology Usage
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="tech_devices_owned"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Which devices do you own or use regularly?</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="e.g. Smartphone, Laptop, Tablet, Smart TV, etc." 
                          />
                        </FormControl>
                        <FormDescription>
                          List the electronic devices you use most often
                        </FormDescription>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("tech_devices_owned", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="tech_social_media"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Which social media platforms do you use?</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="e.g. Facebook, Instagram, Twitter, LinkedIn, etc." 
                          />
                        </FormControl>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("tech_social_media", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="tech_internet_hours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How many hours do you spend online daily?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select hours" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="less_than_1">Less than 1 hour</SelectItem>
                            <SelectItem value="1_3">1-3 hours</SelectItem>
                            <SelectItem value="4_6">4-6 hours</SelectItem>
                            <SelectItem value="7_9">7-9 hours</SelectItem>
                            <SelectItem value="10_plus">10+ hours</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("tech_internet_hours", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="tech_preferences"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>
                          How would you describe your relationship with technology?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Describe your comfort level, interest in new technologies, etc..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("tech_preferences", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between mt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveSection("shopping")}
                  >
                    Previous Section
                  </Button>
                  <Button 
                    type="button"
                    onClick={() => setActiveSection("entertainment")}
                  >
                    Next Section <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Entertainment Section */}
            <AccordionItem value="entertainment">
              <AccordionTrigger className="text-lg font-medium">
                Entertainment & Leisure
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="entertainment_streaming"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Which streaming services do you subscribe to?</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="e.g. Netflix, Hulu, Spotify, etc." 
                          />
                        </FormControl>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("entertainment_streaming", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="entertainment_genres"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>What are your favorite entertainment genres?</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="e.g. Sci-Fi, Comedy, Action, Pop Music, etc." 
                          />
                        </FormControl>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("entertainment_genres", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="entertainment_free_time"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>
                          How do you typically spend your free time?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Describe your hobbies, activities, and leisure preferences..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("entertainment_free_time", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between mt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveSection("technology")}
                  >
                    Previous Section
                  </Button>
                  <Button 
                    type="button"
                    onClick={() => setActiveSection("health")}
                  >
                    Next Section <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Health Section */}
            <AccordionItem value="health">
              <AccordionTrigger className="text-lg font-medium">
                Health & Lifestyle
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="health_exercise"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How often do you exercise?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="several_times_week">Several times a week</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="several_times_month">Several times a month</SelectItem>
                            <SelectItem value="rarely">Rarely</SelectItem>
                            <SelectItem value="never">Never</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("health_exercise", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="health_sleep"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How many hours do you sleep on average?</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select hours" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="less_than_5">Less than 5 hours</SelectItem>
                            <SelectItem value="5_6">5-6 hours</SelectItem>
                            <SelectItem value="7_8">7-8 hours</SelectItem>
                            <SelectItem value="9_plus">9+ hours</SelectItem>
                            <SelectItem value="irregular">Irregular schedule</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline"
                          className="mt-2"
                          onClick={() => saveTemplate("health_sleep", field.value)}
                          disabled={!field.value}
                        >
                          <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                        </Button>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="health_diet"
                    render={({ field }) => (
                      <FormItem className="col-span-full">
                        <FormLabel>
                          How would you describe your eating habits?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Describe your dietary preferences, restrictions, or typical meals..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("health_diet", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between mt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveSection("entertainment")}
                  >
                    Previous Section
                  </Button>
                  <Button 
                    type="button"
                    onClick={() => setActiveSection("opinions")}
                  >
                    Next Section <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Opinions Section */}
            <AccordionItem value="opinions">
              <AccordionTrigger className="text-lg font-medium">
                Opinions & Perspectives
              </AccordionTrigger>
              <AccordionContent>
                <div className="grid grid-cols-1 gap-6 mb-6">
                  <FormField
                    control={form.control}
                    name="opinions_environment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          What are your views on environmental issues?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Share your perspective on climate change, sustainability, etc..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("opinions_environment", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="opinions_technology"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          What are your thoughts on emerging technologies like AI?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Share your views on technological advancements..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("opinions_technology", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="opinions_politics"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          How would you describe your political views?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Share your general political perspective (as comfortable)..."
                            maxLength={MAX_RESPONSE_LENGTH}
                          />
                        </FormControl>
                        <FormDescription>
                          This helps the bot respond appropriately to political survey questions. You can be as vague or specific as you're comfortable with.
                        </FormDescription>
                        <div className="flex justify-between items-center mt-2">
                          <Button 
                            type="button" 
                            size="sm" 
                            variant="outline"
                            onClick={() => saveTemplate("opinions_politics", field.value)}
                            disabled={!field.value}
                          >
                            <Save className="h-3.5 w-3.5 mr-1" /> Save This Response
                          </Button>
                          <p className="text-xs text-muted-foreground">
                            {countCharacters(field.value)}
                          </p>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-between mt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveSection("health")}
                  >
                    Previous Section
                  </Button>
                  <Button type="submit" className="bg-primary text-primary-foreground">
                    Save All Responses
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </form>
      </Form>
    </div>
  );
}