import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    // Check if we have data already
    const existingUser = await db.query.userProfiles.findFirst({
      where: (userProfiles, { eq }) => eq(userProfiles.username, "john_smith")
    });

    if (existingUser) {
      console.log("Database already seeded.");
      return;
    }

    // Seed user profile
    const [profile] = await db.insert(schema.userProfiles).values({
      username: "john_smith",
      password: "secure_password_hash", // In production, should be hashed
      fullName: "John Smith",
      email: "john@example.com",
      age: 32,
      gender: "Male",
      location: "New York, NY",
      occupation: "Software Developer",
      incomeRange: "$50,001 - $75,000",
      interests: ["Technology", "Travel", "Food & Dining", "Fitness"]
    }).returning();

    // Seed bot settings
    await db.insert(schema.botSettings).values({
      profileId: profile.id,
      responseMinDelay: 5,
      responseMaxDelay: 15,
      enableTypos: true,
      enableVariation: true,
      enableConversational: true,
      minPayout: "0.50",
      maxDuration: 20
    });

    // Seed survey providers
    const [provider1] = await db.insert(schema.surveyProviders).values({
      name: "SurveyJunkie",
      url: "https://www.surveyjunkie.com",
      active: true
    }).returning();

    const [provider2] = await db.insert(schema.surveyProviders).values({
      name: "SwagBucks",
      url: "https://www.swagbucks.com",
      active: true
    }).returning();

    const [provider3] = await db.insert(schema.surveyProviders).values({
      name: "InboxDollars",
      url: "https://www.inboxdollars.com",
      active: true
    }).returning();

    // Seed surveys
    const [survey1] = await db.insert(schema.surveys).values({
      providerId: provider1.id,
      name: "Consumer Product Preferences",
      description: "Survey about consumer product preferences and shopping habits",
      externalId: "CPP-2023-06-15-123",
      estimatedDuration: 20,
      payout: "2.50",
      status: "active"
    }).returning();

    const [survey2] = await db.insert(schema.surveys).values({
      providerId: provider2.id,
      name: "Technology Usage Study",
      description: "Study about technology usage patterns and preferences",
      externalId: "TUS-2023-06-15-456",
      estimatedDuration: 10,
      payout: "1.75",
      status: "active"
    }).returning();

    const [survey3] = await db.insert(schema.surveys).values({
      providerId: provider3.id,
      name: "Financial Services Feedback",
      description: "Feedback survey about financial services and banking habits",
      externalId: "FSF-2023-06-15-789",
      estimatedDuration: 25,
      payout: "3.25",
      status: "active"
    }).returning();

    // Seed bot jobs
    const [job1] = await db.insert(schema.botJobs).values({
      profileId: profile.id,
      surveyId: survey1.id,
      status: "in_progress",
      progress: 65,
      startedAt: new Date(Date.now() - 15 * 60 * 1000) // 15 minutes ago
    }).returning();

    const [job2] = await db.insert(schema.botJobs).values({
      profileId: profile.id,
      surveyId: survey2.id,
      status: "in_progress",
      progress: 30,
      startedAt: new Date(Date.now() - 5 * 60 * 1000) // 5 minutes ago
    }).returning();

    const [job3] = await db.insert(schema.botJobs).values({
      profileId: profile.id,
      surveyId: survey3.id,
      status: "just_started",
      progress: 5,
      startedAt: new Date(Date.now() - 2 * 60 * 1000) // 2 minutes ago
    }).returning();

    // Seed response templates
    await db.insert(schema.responseTemplates).values([
      {
        profileId: profile.id,
        category: "Shopping",
        content: "I prefer shopping online for convenience, but still enjoy visiting physical stores for clothing and groceries."
      },
      {
        profileId: profile.id,
        category: "Technology",
        content: "I consider myself tech-savvy and enjoy trying new devices and apps, but I'm also concerned about privacy and security."
      },
      {
        profileId: profile.id,
        category: "Finance",
        content: "I'm fairly conservative with my finances, focusing on saving for retirement and maintaining an emergency fund."
      }
    ]);

    // Seed survey logs for job1
    await db.insert(schema.surveyLogs).values([
      {
        botJobId: job1.id,
        questionText: "How often do you shop online?",
        questionType: "multiple_choice",
        response: "Several times a month",
        timestamp: new Date(Date.now() - 3 * 60 * 1000) // 3 minutes ago
      },
      {
        botJobId: job1.id,
        questionText: "Rate your satisfaction with your last online purchase",
        questionType: "rating",
        response: "4 out of 5 stars",
        timestamp: new Date(Date.now() - 5 * 60 * 1000) // 5 minutes ago
      }
    ]);

    // Seed survey logs for job2
    await db.insert(schema.surveyLogs).values([
      {
        botJobId: job2.id,
        questionText: "Which social media platforms do you use regularly?",
        questionType: "multiple_select",
        response: "Instagram, Twitter, YouTube",
        timestamp: new Date(Date.now() - 6 * 60 * 1000) // 6 minutes ago
      },
      {
        botJobId: job2.id,
        questionText: "Describe your ideal smartphone features.",
        questionType: "text",
        response: "I'd like to see better battery life and maybe a more durable screen. I think cameras are good enough now, but battery tech needs to improve. Also, I'd appreciate if phones were a bit more repairable.",
        timestamp: new Date(Date.now() - 4 * 60 * 1000) // 4 minutes ago
      }
    ]);

    // Seed statistics for the profile
    await db.insert(schema.statistics).values({
      profileId: profile.id,
      date: new Date(),
      completedSurveys: 24,
      earnings: "42.50",
      successRate: "92.00",
      totalTime: 280 // minutes
    });

    console.log("Database seeded successfully.");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
