import type { Express } from "express";
import { createServer, type Server } from "http";
import * as storage from "./storage";
import { surveyService } from "./services/survey-service";
import { botService } from "./services/bot-service";
import { openaiService } from "./services/openai-service";
import { captchaService } from "./services/captcha-service";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Profile endpoints
  app.get('/api/profile', async (req, res) => {
    try {
      // For demo purposes, return the first user profile
      const profile = await storage.getUserById(1);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      return res.json(profile);
    } catch (error: any) {
      console.error("Error fetching profile:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.put('/api/profile', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, update the first user profile
      const updatedProfile = await storage.updateUser(profileId, req.body);
      
      return res.json(updatedProfile[0]);
    } catch (error: any) {
      console.error("Error updating profile:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Bot settings endpoints
  app.get('/api/bot-settings', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get settings for the first user profile
      const settings = await storage.getBotSettingsByProfileId(profileId);
      
      if (!settings) {
        return res.status(404).json({ message: "Bot settings not found" });
      }
      
      return res.json(settings);
    } catch (error: any) {
      console.error("Error fetching bot settings:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.put('/api/bot-settings', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, update settings for the first user profile
      const settings = await storage.getBotSettingsByProfileId(profileId);
      
      if (!settings) {
        return res.status(404).json({ message: "Bot settings not found" });
      }
      
      const updatedSettings = await storage.updateBotSettings(settings.id, req.body);
      
      return res.json(updatedSettings[0]);
    } catch (error: any) {
      console.error("Error updating bot settings:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Survey providers endpoints
  app.get('/api/survey-providers', async (req, res) => {
    try {
      const providers = await storage.getAllSurveyProviders();
      return res.json(providers);
    } catch (error: any) {
      console.error("Error fetching survey providers:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Bot jobs endpoints
  app.get('/api/bot-jobs', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get jobs for the first user profile
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const status = req.query.status as string;
      const providerId = req.query.providerId ? parseInt(req.query.providerId as string) : undefined;
      
      let fromDate, toDate;
      if (req.query.fromDate && req.query.toDate) {
        fromDate = new Date(req.query.fromDate as string);
        toDate = new Date(req.query.toDate as string);
      }
      
      const jobs = await storage.getBotJobHistory(profileId, page, pageSize, fromDate, toDate, status, providerId);
      
      return res.json(jobs);
    } catch (error: any) {
      console.error("Error fetching bot jobs:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/bot-jobs/active', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get active jobs for the first user profile
      const activeJobs = await storage.getActiveBotJobs(profileId);
      
      return res.json(activeJobs);
    } catch (error: any) {
      console.error("Error fetching active bot jobs:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/bot-jobs/history', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get job history for the first user profile
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const status = req.query.status as string;
      const providerId = req.query.providerId ? parseInt(req.query.providerId as string) : undefined;
      
      let fromDate, toDate;
      if (req.query.fromDate && req.query.toDate) {
        fromDate = new Date(req.query.fromDate as string);
        toDate = new Date(req.query.toDate as string);
      }
      
      const jobs = await storage.getBotJobHistory(profileId, page, pageSize, fromDate, toDate, status, providerId);
      
      return res.json(jobs);
    } catch (error: any) {
      console.error("Error fetching bot job history:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/bot-jobs', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, create job for the first user profile
      const { surveyId } = req.body;
      
      if (!surveyId) {
        return res.status(400).json({ message: "Survey ID is required" });
      }
      
      const survey = await storage.getSurveyById(surveyId);
      
      if (!survey) {
        return res.status(404).json({ message: "Survey not found" });
      }
      
      const newJob = await storage.createBotJob({
        profileId,
        surveyId,
        status: "pending",
        progress: 0,
        startedAt: new Date()
      });
      
      // Start the bot process for this job
      botService.startBotJob(newJob[0].id);
      
      return res.status(201).json(newJob[0]);
    } catch (error: any) {
      console.error("Error creating bot job:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Response templates endpoints
  app.get('/api/response-templates', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get templates for the first user profile
      const templates = await storage.getResponseTemplates(profileId);
      
      return res.json(templates);
    } catch (error: any) {
      console.error("Error fetching response templates:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/response-templates/categories', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get template categories for the first user profile
      const categories = await storage.getResponseTemplateCategories(profileId);
      
      return res.json(categories);
    } catch (error: any) {
      console.error("Error fetching template categories:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/response-templates', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, create template for the first user profile
      const { category, content } = req.body;
      
      if (!category || !content) {
        return res.status(400).json({ message: "Category and content are required" });
      }
      
      const newTemplate = await storage.createResponseTemplate({
        profileId,
        category,
        content
      });
      
      return res.status(201).json(newTemplate[0]);
    } catch (error: any) {
      console.error("Error creating response template:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.put('/api/response-templates/:id', async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const { category, content } = req.body;
      
      if (!category || !content) {
        return res.status(400).json({ message: "Category and content are required" });
      }
      
      const template = await storage.getResponseTemplateById(templateId);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      const updatedTemplate = await storage.updateResponseTemplate(templateId, {
        category,
        content
      });
      
      return res.json(updatedTemplate[0]);
    } catch (error: any) {
      console.error("Error updating response template:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.delete('/api/response-templates/:id', async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      
      const template = await storage.getResponseTemplateById(templateId);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      await storage.deleteResponseTemplate(templateId);
      
      return res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting response template:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Survey logs endpoints
  app.get('/api/survey-logs/recent', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get logs for the first user profile
      const limit = parseInt(req.query.limit as string) || 20;
      const logs = await storage.getRecentSurveyLogs(profileId, limit);
      
      // Format logs for frontend
      const formattedLogs = logs.map(log => ({
        id: log.id,
        timestamp: log.timestamp,
        botId: 1, // Using a default bot ID for simplicity
        surveyName: log.botJob.survey.name,
        action: log.questionText || `Processed ${log.questionType} question`,
        response: log.response,
        type: getLogTypeFromQuestionType(log.questionType)
      }));
      
      return res.json(formattedLogs);
    } catch (error: any) {
      console.error("Error fetching survey logs:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  // Survey Learning Data endpoints
  app.get('/api/learning-data', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, use the first profile
      const category = req.query.category as string | undefined;
      
      const data = await storage.getLearningData(profileId, category);
      return res.json(data);
    } catch (error: any) {
      console.error('Error fetching learning data:', error);
      return res.status(500).json({ message: error.message || 'Error fetching learning data' });
    }
  });
  
  app.get('/api/learning-data/categories', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, use the first profile
      const categories = await storage.getLearningCategories(profileId);
      return res.json(categories);
    } catch (error: any) {
      console.error('Error fetching learning categories:', error);
      return res.status(500).json({ message: error.message || 'Error fetching learning categories' });
    }
  });
  
  app.get('/api/learning-data/:category', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, use the first profile
      const { category } = req.params;
      
      const data = await storage.getLearningDataByCategory(profileId, category);
      return res.json(data);
    } catch (error: any) {
      console.error('Error fetching learning data by category:', error);
      return res.status(500).json({ message: error.message || 'Error fetching learning data by category' });
    }
  });
  
  app.post('/api/learning-data', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, use the first profile
      const { category, subcategory, content } = req.body;
      
      if (!category || !subcategory || !content) {
        return res.status(400).json({ message: 'Missing required fields: category, subcategory, content' });
      }
      
      const result = await storage.upsertLearningData(profileId, category, subcategory, content);
      return res.json(result[0]);
    } catch (error: any) {
      console.error('Error saving learning data:', error);
      return res.status(500).json({ message: error.message || 'Error saving learning data' });
    }
  });
  
  app.delete('/api/learning-data/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      if (!id || isNaN(Number(id))) {
        return res.status(400).json({ message: 'Invalid ID' });
      }
      
      const result = await storage.deleteLearningData(Number(id));
      return res.json(result[0]);
    } catch (error: any) {
      console.error('Error deleting learning data:', error);
      return res.status(500).json({ message: error.message || 'Error deleting learning data' });
    }
  });
  
  // Statistics endpoints
  // CAPTCHA related endpoints
  app.post('/api/captcha/solve', async (req, res) => {
    try {
      const { imageBase64, profileId = 1 } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ message: "Image data is required" });
      }
      
      // Check if we have access to OpenAI API
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ message: "OpenAI API key not configured" });
      }
      
      const startTime = Date.now();
      const solution = await captchaService.solveCaptchaWithOpenAI(imageBase64);
      const solveTimeSeconds = (Date.now() - startTime) / 1000;
      
      // Record the solve attempt
      await captchaService.recordCaptchaSolveAttempt(
        profileId,
        !!solution, // successful if we got a non-empty solution
        solveTimeSeconds,
        'text'
      );
      
      return res.json({ 
        success: !!solution,
        solution,
        solveTimeSeconds
      });
    } catch (error: any) {
      console.error("Error solving CAPTCHA:", error);
      return res.status(500).json({ message: error.message || "Error solving CAPTCHA" });
    }
  });
  
  app.post('/api/captcha/is-captcha', async (req, res) => {
    try {
      const { imageBase64 } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ message: "Image data is required" });
      }
      
      // Check if we have access to OpenAI API
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ message: "OpenAI API key not configured" });
      }
      
      const isCaptcha = await captchaService.isCaptchaImage(imageBase64);
      
      return res.json({ isCaptcha });
    } catch (error: any) {
      console.error("Error checking CAPTCHA image:", error);
      return res.status(500).json({ message: error.message || "Error checking CAPTCHA image" });
    }
  });
  
  app.get('/api/captcha/stats', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get stats for the first user profile
      const today = new Date();
      const stats = await storage.getCaptchaStats(profileId, today);
      
      if (!stats) {
        return res.json({
          totalAttempts: 0,
          successfulAttempts: 0,
          successRate: 0,
          averageSolveTime: 0
        });
      }
      
      const successRate = stats.totalAttempts > 0 
        ? (stats.successfulAttempts / stats.totalAttempts) * 100 
        : 0;
      
      return res.json({
        ...stats,
        successRate
      });
    } catch (error: any) {
      console.error("Error fetching CAPTCHA stats:", error);
      return res.status(500).json({ message: error.message || "Error fetching CAPTCHA stats" });
    }
  });
  
  app.get('/api/captcha/success-rate', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get stats for the first user profile
      
      // Get date range from query params or use last 7 days
      let fromDate = new Date();
      fromDate.setDate(fromDate.getDate() - 7);
      let toDate = new Date();
      
      if (req.query.fromDate && req.query.toDate) {
        fromDate = new Date(req.query.fromDate as string);
        toDate = new Date(req.query.toDate as string);
      }
      
      const successRate = await storage.getCaptchaSuccessRate(profileId, fromDate, toDate);
      
      return res.json({ successRate });
    } catch (error: any) {
      console.error("Error calculating CAPTCHA success rate:", error);
      return res.status(500).json({ message: error.message || "Error calculating CAPTCHA success rate" });
    }
  });

  app.get('/api/statistics/today', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get stats for the first user profile
      const stats = await storage.getDailyStatistics(profileId);
      
      if (!stats) {
        return res.json({
          completedSurveys: 0,
          earnings: "0.00",
          successRate: "0.00",
          activeBots: 0
        });
      }
      
      // Get active bot count
      const activeJobs = await storage.getActiveBotJobs(profileId);
      
      return res.json({
        ...stats,
        activeBots: activeJobs.length
      });
    } catch (error: any) {
      console.error("Error fetching daily statistics:", error);
      return res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/statistics/earnings', async (req, res) => {
    try {
      const profileId = 1; // For demo purposes, get earnings for the first user profile
      const fromDate = req.query.from ? new Date(req.query.from as string) : new Date(new Date().setDate(new Date().getDate() - 30));
      const toDate = req.query.to ? new Date(req.query.to as string) : new Date();
      const periodView = req.query.periodView as string || 'daily';
      
      const earningsData = await storage.getEarningsData(profileId, fromDate, toDate, periodView);
      
      return res.json(earningsData);
    } catch (error: any) {
      console.error("Error fetching earnings data:", error);
      return res.status(500).json({ message: error.message });
    }
  });

  // Start or test a survey bot with OpenAI
  // Training data submission endpoint
  app.post('/api/bot/train', async (req, res) => {
    try {
      const { question, response, category, subcategory, profileId = 1 } = req.body;
      
      if (!question || !response) {
        return res.status(400).json({ message: "Question and response are required" });
      }
      
      // Learn from the response
      await botService.learnFromResponse(
        question,
        response,
        category || '',
        subcategory || '',
        profileId
      );
      
      return res.json({ success: true, message: "Training data saved successfully" });
    } catch (error: any) {
      console.error("Error saving training data:", error);
      return res.status(500).json({ message: error.message || "Error saving training data" });
    }
  });

  app.post('/api/bot/handle-captcha', async (req, res) => {
    try {
      const { imageBase64, submitUrl, formData, profileId = 1 } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ message: "CAPTCHA image data is required" });
      }
      
      // Check if we have access to OpenAI API
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ message: "OpenAI API key not configured" });
      }
      
      // Handle the CAPTCHA challenge
      const result = await botService.handleCaptchaChallenge(
        imageBase64,
        profileId,
        submitUrl,
        formData
      );
      
      return res.json(result);
    } catch (error: any) {
      console.error("Error handling CAPTCHA challenge:", error);
      return res.status(500).json({ message: error.message || "Error handling CAPTCHA challenge" });
    }
  });

  app.post('/api/bot/test', async (req, res) => {
    try {
      const { question, profileId = 1 } = req.body;
      
      if (!question) {
        return res.status(400).json({ message: "Question is required" });
      }
      
      const profile = await storage.getUserById(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      const botSettings = await storage.getBotSettingsByProfileId(profileId);
      if (!botSettings) {
        return res.status(404).json({ message: "Bot settings not found" });
      }
      
      const response = await openaiService.generateResponse(question, profile, botSettings);
      
      return res.json({ response });
    } catch (error: any) {
      console.error("Error testing bot:", error);
      return res.status(500).json({ message: error.message });
    }
  });

  return httpServer;
}

// Helper function to determine log type from question type
function getLogTypeFromQuestionType(questionType: string): string {
  if (questionType.includes('start')) return 'start';
  if (questionType.includes('complete')) return 'complete';
  if (questionType.includes('error')) return 'error';
  return 'answer';
}
