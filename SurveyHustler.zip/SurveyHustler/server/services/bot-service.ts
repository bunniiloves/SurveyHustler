import * as storage from "../storage";
import { surveyService } from "./survey-service";
import { openaiService } from "./openai-service";
import { captchaService } from "./captcha-service";
import { QuestionType, SurveyQuestion, BotResponse } from "@/lib/types";

class BotService {
  /**
   * Starts a bot job to complete a survey
   */
  async startBotJob(jobId: number): Promise<void> {
    try {
      console.log(`Starting bot job ${jobId}`);
      
      // Get the job details
      const job = await storage.getBotJobById(jobId);
      if (!job) {
        throw new Error(`Job with id ${jobId} not found`);
      }
      
      // Update job status to just started
      await storage.updateBotJob(jobId, {
        status: "just_started",
        progress: 5
      });
      
      // Create a starting log entry
      await storage.createSurveyLog({
        botJobId: jobId,
        questionType: "started",
        timestamp: new Date()
      });
      
      // Get the profile and bot settings
      const profile = await storage.getUserById(job.profileId);
      const botSettings = await storage.getBotSettingsByProfileId(job.profileId);
      
      if (!profile || !botSettings) {
        throw new Error("Profile or bot settings not found");
      }
      
      // Process the survey questions (in a real implementation, this would be fetched from the provider's API)
      const questions = await surveyService.processSurveyQuestions(job.surveyId, job.profileId);
      
      // Update job status to in progress
      await storage.updateBotJob(jobId, {
        status: "in_progress",
        progress: 10
      });
      
      // Process each question with delays to simulate human response times
      let currentProgress = 10;
      const progressIncrement = Math.floor(90 / questions.length);
      
      for (let i = 0; i < questions.length; i++) {
        const question = questions[i];
        
        // Generate a random delay within the configured range
        const minDelay = botSettings.responseMinDelay * 1000;
        const maxDelay = botSettings.responseMaxDelay * 1000;
        const delay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
        
        // Simulate human delay - we're using setTimeout here for simplicity
        await new Promise(resolve => setTimeout(resolve, delay));
        
        // Generate a response to the question
        const response = await this.generateResponse(question, profile, botSettings);
        
        // Process the response
        await surveyService.processSurveyResponse(jobId, question, response);
        
        // Update progress
        currentProgress += progressIncrement;
        await storage.updateBotJob(jobId, {
          progress: Math.min(95, currentProgress)
        });
      }
      
      // Simulate a final delay before completing the survey
      const finalDelay = Math.floor(Math.random() * 5000) + 2000;
      await new Promise(resolve => setTimeout(resolve, finalDelay));
      
      // Complete the survey
      const payout = job.survey.payout;
      await surveyService.completeSurveyJob(jobId, "completed", payout);
      
      console.log(`Completed bot job ${jobId}`);
    } catch (error: any) {
      console.error(`Error in bot job ${jobId}:`, error);
      
      // Update job with error status
      await storage.updateBotJob(jobId, {
        status: "error",
        errorMessage: error.message
      });
      
      // Log the error
      await storage.createSurveyLog({
        botJobId: jobId,
        questionType: "error",
        response: error.message,
        timestamp: new Date()
      });
      
      // Complete the job with error
      await surveyService.completeSurveyJob(jobId, "error");
    }
  }
  
  /**
   * Generates a response to a survey question
   */
  async generateResponse(
    question: SurveyQuestion, 
    profile: any, 
    botSettings: any
  ): Promise<BotResponse> {
    const responseTime = Date.now();
    
    try {
      let response: string | string[] | number;
      
      // Use response templates for text questions if available
      if (question.type === QuestionType.TEXT) {
        // Try to find a relevant template based on question text
        const templates = await storage.getResponseTemplates(profile.id);
        const relevantTemplate = templates.find(template => 
          question.text.toLowerCase().includes(template.category.toLowerCase()) ||
          template.category.toLowerCase().includes(question.text.split(' ')[0].toLowerCase())
        );
        
        if (relevantTemplate) {
          // Use template with slight variations if enabled
          if (botSettings.enableVariation) {
            response = await openaiService.modifyResponse(
              relevantTemplate.content,
              botSettings.enableTypos,
              botSettings.enableConversational
            );
          } else {
            response = relevantTemplate.content;
          }
        } else {
          // Generate a response with OpenAI
          response = await openaiService.generateResponse(
            question.text,
            profile,
            botSettings
          );
        }
      }
      // For multiple choice questions
      else if (question.type === QuestionType.MULTIPLE_CHOICE) {
        // Randomly select an option
        const randomIndex = Math.floor(Math.random() * question.options!.length);
        response = question.options![randomIndex];
      }
      // For multiple select questions
      else if (question.type === QuestionType.MULTIPLE_SELECT) {
        // Select a random number of options (1 to all)
        const numOptions = Math.floor(Math.random() * question.options!.length) + 1;
        const shuffled = [...question.options!].sort(() => 0.5 - Math.random());
        response = shuffled.slice(0, numOptions);
      }
      // For rating questions
      else if (question.type === QuestionType.RATING) {
        // Generate a random rating, biased towards 4-5 stars
        const weights = [0.05, 0.1, 0.2, 0.35, 0.3]; // Weights for 1-5 stars
        const random = Math.random();
        let cumulativeWeight = 0;
        let rating = 1;
        
        for (let i = 0; i < weights.length; i++) {
          cumulativeWeight += weights[i];
          if (random <= cumulativeWeight) {
            rating = i + 1;
            break;
          }
        }
        
        response = rating;
      }
      // Default fallback for other question types
      else {
        // Generate a generic response
        response = "Not applicable";
      }
      
      return {
        questionId: question.id,
        response,
        responseTime: Date.now() - responseTime
      };
    } catch (error: any) {
      console.error(`Error generating response for question ${question.id}:`, error);
      
      // Provide a fallback response
      if (question.type === QuestionType.MULTIPLE_CHOICE && question.options && question.options.length > 0) {
        return {
          questionId: question.id,
          response: question.options[0],
          responseTime: Date.now() - responseTime
        };
      } else if (question.type === QuestionType.MULTIPLE_SELECT && question.options && question.options.length > 0) {
        return {
          questionId: question.id,
          response: [question.options[0]],
          responseTime: Date.now() - responseTime
        };
      } else if (question.type === QuestionType.RATING) {
        return {
          questionId: question.id,
          response: 3,
          responseTime: Date.now() - responseTime
        };
      } else {
        return {
          questionId: question.id,
          response: "I'm not sure how to respond to this question.",
          responseTime: Date.now() - responseTime
        };
      }
    }
  }
  
  /**
   * Stops a running bot job
   */
  async stopBotJob(jobId: number): Promise<void> {
    const job = await storage.getBotJobById(jobId);
    if (!job) {
      throw new Error(`Job with id ${jobId} not found`);
    }
    
    // Update job status to stopped
    await storage.updateBotJob(jobId, {
      status: "stopped",
      completedAt: new Date()
    });
    
    // Create a stopped log entry
    await storage.createSurveyLog({
      botJobId: jobId,
      questionType: "stopped",
      timestamp: new Date()
    });
  }
  
  /**
   * Handles CAPTCHA challenges during survey completion
   */
  async handleCaptchaChallenge(
    imageBase64: string,
    profileId: number,
    submitUrl?: string,
    formData?: Record<string, string>
  ): Promise<{success: boolean, solution: string}> {
    try {
      console.log("Handling CAPTCHA challenge for profile", profileId);
      
      // First check if the image is actually a CAPTCHA
      const isCaptcha = await captchaService.isCaptchaImage(imageBase64);
      
      if (!isCaptcha) {
        console.log("Image is not a CAPTCHA");
        return { success: false, solution: "" };
      }
      
      const startTime = Date.now();
      // Solve the CAPTCHA using OpenAI
      const solution = await captchaService.solveCaptchaWithOpenAI(imageBase64);
      const solveTimeSeconds = (Date.now() - startTime) / 1000;
      
      const success = !!solution;
      
      // Record the CAPTCHA solve attempt
      await captchaService.recordCaptchaSolveAttempt(
        profileId,
        success,
        solveTimeSeconds,
        'text'
      );
      
      // If we have a submit URL and form data, submit the solution
      if (success && submitUrl && formData) {
        await captchaService.processCaptchaChallenge(
          `data:image/jpeg;base64,${imageBase64}`,
          submitUrl,
          { ...formData, captcha: solution }
        );
      }
      
      return {
        success,
        solution
      };
    } catch (error) {
      console.error("Error handling CAPTCHA challenge:", error);
      return { success: false, solution: "" };
    }
  }
  
  /**
   * Learns from a submitted answer to improve future responses
   */
  async learnFromResponse(
    question: string,
    response: string,
    category: string,
    subcategory: string,
    profileId: number
  ): Promise<void> {
    try {
      // Analyze the question to extract main topics
      const analysis = await openaiService.analyzeSurveyQuestion(question);
      
      // Use provided category or first topic from analysis
      const finalCategory = category || analysis.topics[0] || "General";
      
      // Use provided subcategory or derive from question
      const finalSubcategory = subcategory || question.split(" ").slice(0, 5).join(" ") + "...";
      
      // Store the learning data
      await storage.upsertLearningData(
        profileId,
        finalCategory,
        finalSubcategory,
        response
      );
      
      console.log(`Learned new response for ${finalCategory}/${finalSubcategory}`);
    } catch (error) {
      console.error("Error learning from response:", error);
    }
  }
}

export const botService = new BotService();
