import OpenAI from "openai";
import * as storage from "../storage";
import axios from "axios";
import fs from "fs";
import path from "path";
import { Buffer } from "buffer";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize OpenAI API client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

class CaptchaService {
  /**
   * Solves a CAPTCHA image using OpenAI vision capabilities
   */
  async solveCaptchaWithOpenAI(captchaImageBase64: string): Promise<string> {
    try {
      console.log("Attempting to solve CAPTCHA with OpenAI vision model");
      
      const response = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          {
            role: "system",
            content: "You are a CAPTCHA solving assistant. Extract text or identify objects in the CAPTCHA images provided. Return ONLY the text/numbers/solution with no explanation or additional text."
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Please solve this CAPTCHA. Return ONLY the characters/solution with no additional text."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${captchaImageBase64}`
                }
              }
            ],
          },
        ],
        max_tokens: 100,
      });

      const solution = response.choices[0].message.content?.trim();
      console.log(`CAPTCHA solution: ${solution}`);
      return solution || "";
    } catch (error: any) {
      console.error("Error solving CAPTCHA with OpenAI:", error);
      throw new Error(`Failed to solve CAPTCHA: ${error.message}`);
    }
  }

  /**
   * Identifies if an image contains a CAPTCHA
   */
  async isCaptchaImage(imageBase64: string): Promise<boolean> {
    try {
      const response = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          {
            role: "system",
            content: "You are analyzing images to determine if they contain a CAPTCHA. Respond with 'yes' if the image contains a CAPTCHA, and 'no' if it does not."
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Does this image contain a CAPTCHA? Respond with only 'yes' or 'no'."
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${imageBase64}`
                }
              }
            ],
          },
        ],
        max_tokens: 10,
      });

      const result = response.choices[0].message.content?.trim().toLowerCase();
      return result === 'yes';
    } catch (error: any) {
      console.error("Error identifying CAPTCHA image:", error);
      return false;
    }
  }

  /**
   * Downloads a CAPTCHA image from a URL and returns it as base64
   */
  async downloadCaptchaImage(url: string): Promise<string> {
    try {
      const response = await axios.get(url, {
        responseType: 'arraybuffer'
      });
      
      const buffer = Buffer.from(response.data, 'binary');
      return buffer.toString('base64');
    } catch (error: any) {
      console.error("Error downloading CAPTCHA image:", error);
      throw new Error(`Failed to download CAPTCHA image: ${error.message}`);
    }
  }

  /**
   * Process a CAPTCHA challenge and submit the solution
   */
  async processCaptchaChallenge(
    captchaUrl: string,
    submitUrl: string,
    formData: Record<string, string> = {}
  ): Promise<boolean> {
    try {
      // Download the CAPTCHA image
      const captchaImageBase64 = await this.downloadCaptchaImage(captchaUrl);
      
      // Solve the CAPTCHA
      const solution = await this.solveCaptchaWithOpenAI(captchaImageBase64);
      
      if (!solution) {
        console.error("Failed to solve CAPTCHA");
        return false;
      }
      
      // Submit the CAPTCHA solution
      formData.captcha = solution;
      
      const response = await axios.post(submitUrl, formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });
      
      // Check if submission was successful (this will depend on the specific application)
      return response.status === 200;
    } catch (error: any) {
      console.error("Error processing CAPTCHA challenge:", error);
      return false;
    }
  }
  
  /**
   * Records CAPTCHA solving statistics
   */
  async recordCaptchaSolveAttempt(
    profileId: number,
    successful: boolean,
    solveTimeSeconds: number = 0,
    captchaType: string = 'text'
  ): Promise<void> {
    try {
      // Get the current bot settings
      const botSettings = await storage.getBotSettingsByProfileId(profileId);
      
      if (!botSettings) {
        console.error(`Bot settings not found for profile ${profileId}`);
        return;
      }
      
      // Update CAPTCHA statistics
      await storage.upsertCaptchaStats(
        profileId,
        {
          totalAttempts: 1,
          successfulAttempts: successful ? 1 : 0,
          averageSolveTime: solveTimeSeconds,
          captchaType
        }
      );
      
      console.log(`CAPTCHA solve attempt for profile ${profileId}: ${successful ? 'success' : 'failure'}, type: ${captchaType}, time: ${solveTimeSeconds}s`);
    } catch (error) {
      console.error("Error recording CAPTCHA solve attempt:", error);
    }
  }
}

export const captchaService = new CaptchaService();