import OpenAI from "openai";
import * as storage from "../storage";

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize OpenAI API client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "dummy-key" // Use the environment variable
});

class OpenAIService {
  /**
   * Generates a human-like response to a survey question based on user profile
   */
  async generateResponse(
    question: string,
    profile: any,
    botSettings: any
  ): Promise<string> {
    try {
      // Try to categorize the question and find relevant learning data
      const questionAnalysis = await this.analyzeSurveyQuestion(question);
      const profileId = profile.id || 1;
      
      // Get all learning data for this profile
      const learningData = await storage.getLearningData(profileId);
      
      // Find any specific learning data that might be applicable to this question
      let relevantLearningContent = "";
      if (learningData && learningData.length > 0) {
        // Look for exact category matches first (using the analyzed topics)
        const exactMatches = learningData.filter(item => 
          questionAnalysis.topics.some(topic => 
            topic.toLowerCase() === item.category.toLowerCase()
          )
        );
        
        if (exactMatches.length > 0) {
          relevantLearningContent = exactMatches.map(item => 
            `${item.subcategory}: ${item.content}`
          ).join("\n");
        } else {
          // Fall back to any potentially relevant data
          const potentialMatches = learningData.filter(item => 
            questionAnalysis.topics.some(topic => 
              item.category.toLowerCase().includes(topic.toLowerCase()) || 
              topic.toLowerCase().includes(item.category.toLowerCase())
            )
          );
          
          if (potentialMatches.length > 0) {
            relevantLearningContent = potentialMatches.map(item => 
              `${item.subcategory}: ${item.content}`
            ).join("\n");
          }
        }
      }
      
      // Create a system message that describes the task and includes profile information
      const systemMessage = `You are an AI assistant helping to generate human-like responses to survey questions.
      You should respond as if you were a real person with the following profile:
      
      Name: ${profile.fullName || "John Smith"}
      Age: ${profile.age || "30-35"}
      Gender: ${profile.gender || "Not specified"}
      Location: ${profile.location || "United States"}
      Occupation: ${profile.occupation || "Professional"}
      Income Range: ${profile.incomeRange || "Middle income"}
      Interests: ${profile.interests?.join(", ") || "Technology, Travel"}
      
      ${botSettings.enableTypos ? "Occasionally include minor typos or grammatical errors for authenticity." : "Use correct spelling and grammar."}
      ${botSettings.enableConversational ? "Use a conversational tone with casual phrases, contractions, and natural language patterns." : "Maintain a straightforward, clear tone."}
      ${botSettings.enableVariation ? "Vary your response patterns and sentence structures to avoid detection as AI." : "Keep responses consistent and structured."}
      
      Your response should be thoughtful, personal, and reflect the perspective of someone with this profile.
      The response should be 2-4 sentences long unless a longer answer is specifically requested.
      
      ${relevantLearningContent ? `IMPORTANT - Use the following personal information to inform your response. These are direct answers that this person has provided to similar topics in the past:\n\n${relevantLearningContent}` : ""}`;
      
      // Send the question to the OpenAI API
      const response = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          { role: "system", content: systemMessage },
          { role: "user", content: `Survey Question: ${question}` }
        ],
        temperature: 0.8, // Higher temperature for more creative responses
        max_tokens: 300 // Limit response length
      });
      
      return response.choices[0].message.content || "I'm not sure how to answer that question.";
    } catch (error: any) {
      console.error("Error generating response with OpenAI:", error);
      return "Sorry, I couldn't generate a response at this time.";
    }
  }
  
  /**
   * Modifies an existing response to add variation, typos, or conversational elements
   */
  async modifyResponse(
    originalResponse: string,
    enableTypos: boolean,
    enableConversational: boolean
  ): Promise<string> {
    try {
      // Create a system message for the modification task
      const systemMessage = `You are an AI assistant helping to modify a survey response to make it more human-like.
      Your task is to modify the original response with these requirements:
      
      ${enableTypos ? "Add 1-2 minor, realistic typos or grammatical errors for authenticity." : "Keep correct spelling and grammar."}
      ${enableConversational ? "Add casual phrases, fillers, or conversational elements." : "Maintain the existing tone."}
      
      The modified response should retain the same meaning and key points as the original but feel more naturally human.`;
      
      // Send the request to the OpenAI API
      const response = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          { role: "system", content: systemMessage },
          { role: "user", content: `Original Response: ${originalResponse}` }
        ],
        temperature: 0.7,
        max_tokens: 300
      });
      
      return response.choices[0].message.content || originalResponse;
    } catch (error: any) {
      console.error("Error modifying response with OpenAI:", error);
      return originalResponse; // Return the original response if modification fails
    }
  }
  
  /**
   * Analyzes a survey question to determine the most appropriate response strategy
   */
  async analyzeSurveyQuestion(question: string): Promise<{
    type: string;
    topics: string[];
    recommendedApproach: string;
  }> {
    try {
      const prompt = `Analyze the following survey question and provide:
      1. The most likely question type (multiple choice, open-ended, rating, etc.)
      2. The main topics or themes in the question
      3. A recommended approach for answering authentically
      
      Format your response as JSON with the keys: type, topics, recommendedApproach
      
      Survey Question: ${question}`;
      
      const response = await openai.chat.completions.create({
        model: MODEL,
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        temperature: 0.3
      });
      
      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      return {
        type: result.type || "unknown",
        topics: result.topics || [],
        recommendedApproach: result.recommendedApproach || "Be honest and straightforward"
      };
    } catch (error: any) {
      console.error("Error analyzing question with OpenAI:", error);
      return {
        type: "unknown",
        topics: [],
        recommendedApproach: "Be honest and straightforward"
      };
    }
  }
}

export const openaiService = new OpenAIService();
