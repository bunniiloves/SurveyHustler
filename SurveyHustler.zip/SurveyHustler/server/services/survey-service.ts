import * as storage from "../storage";
import { openaiService } from "./openai-service";
import { SurveyQuestion, QuestionType, BotResponse } from "@/lib/types";

class SurveyService {
  /**
   * Fetches available surveys based on bot settings criteria
   */
  async getAvailableSurveys(minPayout: number, maxDuration: number) {
    return storage.getAvailableSurveys(minPayout, maxDuration);
  }
  
  /**
   * Mocks the survey question processing for different survey providers
   * In a real application, this would interact with the provider's API
   */
  async processSurveyQuestions(surveyId: number, profileId: number): Promise<SurveyQuestion[]> {
    // In a real implementation, this would fetch actual questions from the survey provider's API
    // For this example, we're creating mock questions based on survey ID
    
    // Get the survey details
    const survey = await storage.getSurveyById(surveyId);
    if (!survey) {
      throw new Error(`Survey with id ${surveyId} not found`);
    }
    
    // Generate different question patterns based on survey type/name
    const questions: SurveyQuestion[] = [];
    
    // Consumer products survey pattern
    if (survey.name.toLowerCase().includes("consumer") || survey.name.toLowerCase().includes("product")) {
      questions.push(
        {
          id: `q1_${surveyId}`,
          text: "How often do you shop online?",
          type: QuestionType.MULTIPLE_CHOICE,
          options: ["Several times a week", "Once a week", "Several times a month", "Once a month", "Rarely", "Never"],
          required: true
        },
        {
          id: `q2_${surveyId}`,
          text: "Which of the following product categories do you purchase most frequently?",
          type: QuestionType.MULTIPLE_SELECT,
          options: ["Electronics", "Clothing", "Home goods", "Groceries", "Beauty products", "Books", "Other"],
          required: true
        },
        {
          id: `q3_${surveyId}`,
          text: "Rate your satisfaction with your last online purchase",
          type: QuestionType.RATING,
          options: ["1", "2", "3", "4", "5"],
          required: true
        },
        {
          id: `q4_${surveyId}`,
          text: "Describe what factors influence your decision to purchase products online versus in-store",
          type: QuestionType.TEXT,
          required: true,
          minLength: 50,
          maxLength: 500
        }
      );
    }
    // Technology survey pattern
    else if (survey.name.toLowerCase().includes("tech") || survey.name.toLowerCase().includes("technology")) {
      questions.push(
        {
          id: `q1_${surveyId}`,
          text: "Which devices do you use regularly? (Select all that apply)",
          type: QuestionType.MULTIPLE_SELECT,
          options: ["Smartphone", "Laptop", "Desktop computer", "Tablet", "Smart TV", "Smart watch", "Smart home devices"],
          required: true
        },
        {
          id: `q2_${surveyId}`,
          text: "How many hours per day do you spend using technology devices?",
          type: QuestionType.MULTIPLE_CHOICE,
          options: ["Less than 1 hour", "1-3 hours", "4-6 hours", "7-9 hours", "10+ hours"],
          required: true
        },
        {
          id: `q3_${surveyId}`,
          text: "Which social media platforms do you use regularly?",
          type: QuestionType.MULTIPLE_SELECT,
          options: ["Facebook", "Instagram", "Twitter", "LinkedIn", "TikTok", "YouTube", "Reddit", "None"],
          required: true
        },
        {
          id: `q4_${surveyId}`,
          text: "Describe your ideal smartphone features.",
          type: QuestionType.TEXT,
          required: true,
          minLength: 50,
          maxLength: 500
        }
      );
    }
    // Financial survey pattern
    else if (survey.name.toLowerCase().includes("financial") || survey.name.toLowerCase().includes("finance")) {
      questions.push(
        {
          id: `q1_${surveyId}`,
          text: "Which financial services do you currently use?",
          type: QuestionType.MULTIPLE_SELECT,
          options: ["Checking account", "Savings account", "Credit card", "Investment account", "Mortgage", "Personal loan", "Retirement account"],
          required: true
        },
        {
          id: `q2_${surveyId}`,
          text: "How do you primarily manage your finances?",
          type: QuestionType.MULTIPLE_CHOICE,
          options: ["Mobile banking app", "Desktop online banking", "In-person at bank branch", "ATM", "Phone banking"],
          required: true
        },
        {
          id: `q3_${surveyId}`,
          text: "How satisfied are you with your current banking services?",
          type: QuestionType.RATING,
          options: ["1", "2", "3", "4", "5"],
          required: true
        },
        {
          id: `q4_${surveyId}`,
          text: "What features would you like to see in a financial management app?",
          type: QuestionType.TEXT,
          required: true,
          minLength: 50,
          maxLength: 500
        }
      );
    }
    // Default generic questions
    else {
      questions.push(
        {
          id: `q1_${surveyId}`,
          text: "How would you rate your interest in this topic?",
          type: QuestionType.RATING,
          options: ["1", "2", "3", "4", "5"],
          required: true
        },
        {
          id: `q2_${surveyId}`,
          text: "Which aspect of this topic interests you most?",
          type: QuestionType.MULTIPLE_CHOICE,
          options: ["Learning new information", "Sharing my opinions", "Financial compensation", "Contributing to research", "Other"],
          required: true
        },
        {
          id: `q3_${surveyId}`,
          text: "Please share your thoughts on this topic in detail.",
          type: QuestionType.TEXT,
          required: true,
          minLength: 50,
          maxLength: 300
        }
      );
    }
    
    return questions;
  }
  
  /**
   * Processes a response to a survey question
   */
  async processSurveyResponse(
    jobId: number, 
    question: SurveyQuestion, 
    response: BotResponse
  ): Promise<void> {
    // Create a survey log entry for this question and response
    await storage.createSurveyLog({
      botJobId: jobId,
      questionText: question.text,
      questionType: question.type,
      response: typeof response.response === 'string' 
        ? response.response 
        : Array.isArray(response.response)
          ? response.response.join(", ")
          : response.response.toString(),
      timestamp: new Date()
    });
    
    // In a real implementation, this would send the response to the survey provider's API
    // and handle the response or error
    
    // For this example, we just log the response and return
    console.log(`Processed response for question ${question.id} in job ${jobId}`);
  }
  
  /**
   * Completes a survey job with the final status and earnings
   */
  async completeSurveyJob(jobId: number, status: string, earnedAmount?: string): Promise<void> {
    const job = await storage.getBotJobById(jobId);
    if (!job) {
      throw new Error(`Job with id ${jobId} not found`);
    }
    
    await storage.updateBotJob(jobId, {
      status,
      progress: status === 'completed' ? 100 : job.progress,
      completedAt: new Date(),
      earnedAmount
    });
    
    // If the job is completed successfully, update the statistics
    if (status === 'completed' && earnedAmount) {
      const stats = await storage.getDailyStatistics(job.profileId);
      
      const completedSurveys = (stats?.completedSurveys || 0) + 1;
      const earnings = (parseFloat(stats?.earnings || "0") + parseFloat(earnedAmount)).toString();
      
      // Get all jobs completed today to calculate success rate
      const fromDate = new Date();
      fromDate.setHours(0, 0, 0, 0);
      const toDate = new Date();
      toDate.setHours(23, 59, 59, 999);
      
      const jobHistory = await storage.getBotJobHistory(job.profileId, 1, 100, fromDate, toDate);
      const completedJobs = jobHistory.jobs.filter(j => j.status === 'completed').length;
      const totalJobs = jobHistory.jobs.length;
      const successRate = totalJobs > 0 ? ((completedJobs / totalJobs) * 100).toFixed(2) : "0.00";
      
      // Update statistics
      await storage.upsertDailyStatistics(job.profileId, {
        completedSurveys,
        earnings,
        successRate,
        totalTime: (stats?.totalTime || 0) + job.survey.estimatedDuration
      });
    }
    
    // Create a completion log entry
    await storage.createSurveyLog({
      botJobId: jobId,
      questionType: status === 'completed' ? 'completed' : 'error',
      timestamp: new Date()
    });
  }
}

export const surveyService = new SurveyService();
