import { db } from "@db";
import { 
  userProfiles, 
  botSettings, 
  surveys, 
  surveyProviders, 
  botJobs, 
  responseTemplates,
  surveyLogs,
  statistics,
  surveyLearningData,
  captchaStats
} from "@shared/schema";
import { eq, and, or, desc, asc, gte, lte, isNull, sql, like, count } from "drizzle-orm";
import { format, startOfDay, endOfDay, subDays } from "date-fns";

// User Profiles
export const getUserByUsername = async (username: string) => {
  return db.query.userProfiles.findFirst({
    where: eq(userProfiles.username, username)
  });
};

export const getUserById = async (id: number) => {
  return db.query.userProfiles.findFirst({
    where: eq(userProfiles.id, id)
  });
};

export const updateUser = async (id: number, data: any) => {
  return db.update(userProfiles)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(userProfiles.id, id))
    .returning();
};

// Bot Settings
export const getBotSettingsByProfileId = async (profileId: number) => {
  return db.query.botSettings.findFirst({
    where: eq(botSettings.profileId, profileId)
  });
};

export const updateBotSettings = async (id: number, data: any) => {
  return db.update(botSettings)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(botSettings.id, id))
    .returning();
};

// Survey Providers
export const getAllSurveyProviders = async () => {
  return db.query.surveyProviders.findMany({
    where: eq(surveyProviders.active, true),
    orderBy: asc(surveyProviders.name)
  });
};

export const getSurveyProviderById = async (id: number) => {
  return db.query.surveyProviders.findFirst({
    where: eq(surveyProviders.id, id)
  });
};

// Surveys
export const getAvailableSurveys = async (minPayout: number, maxDuration: number) => {
  return db.query.surveys.findMany({
    where: and(
      eq(surveys.status, "active"),
      sql`CAST(${surveys.payout} AS DECIMAL) >= ${minPayout}`,
      lte(surveys.estimatedDuration, maxDuration)
    ),
    with: {
      provider: true
    },
    orderBy: [
      desc(sql`CAST(${surveys.payout} AS DECIMAL)`),
    ]
  });
};

export const getSurveyById = async (id: number) => {
  return db.query.surveys.findFirst({
    where: eq(surveys.id, id),
    with: {
      provider: true
    }
  });
};

// Bot Jobs
export const createBotJob = async (data: any) => {
  return db.insert(botJobs)
    .values(data)
    .returning();
};

export const getActiveBotJobs = async (profileId: number) => {
  return db.query.botJobs.findMany({
    where: and(
      eq(botJobs.profileId, profileId),
      sql`${botJobs.status} IN ('pending', 'in_progress', 'just_started')`
    ),
    with: {
      survey: {
        with: {
          provider: true
        }
      }
    },
    orderBy: [
      desc(botJobs.createdAt)
    ]
  });
};

export const getBotJobById = async (id: number) => {
  return db.query.botJobs.findFirst({
    where: eq(botJobs.id, id),
    with: {
      survey: {
        with: {
          provider: true
        }
      }
    }
  });
};

export const getBotJobHistory = async (profileId: number, page: number = 1, pageSize: number = 10, dateFrom?: Date, dateTo?: Date, status?: string, providerId?: number) => {
  const conditions = [eq(botJobs.profileId, profileId)];
  
  if (dateFrom && dateTo) {
    conditions.push(gte(botJobs.createdAt, startOfDay(dateFrom)));
    conditions.push(lte(botJobs.createdAt, endOfDay(dateTo)));
  }
  
  if (status && status !== 'all') {
    conditions.push(eq(botJobs.status, status));
  }
  
  let jobsQuery = db.query.botJobs.findMany({
    where: and(...conditions),
    with: {
      survey: {
        with: {
          provider: true
        }
      }
    },
    orderBy: [
      desc(botJobs.createdAt)
    ],
    offset: (page - 1) * pageSize,
    limit: pageSize
  });
  
  if (providerId && providerId !== -1) {
    jobsQuery = db.query.botJobs.findMany({
      where: and(...conditions),
      with: {
        survey: {
          where: eq(surveys.providerId, providerId),
          with: {
            provider: true
          }
        }
      },
      orderBy: [
        desc(botJobs.createdAt)
      ],
      offset: (page - 1) * pageSize,
      limit: pageSize
    });
  }
  
  const jobs = await jobsQuery;
  
  // Get total count for pagination
  const countResult = await db.select({ count: count() })
    .from(botJobs)
    .where(and(...conditions));
  
  const total = countResult[0].count;
  
  return {
    jobs,
    total,
    page,
    pageSize,
    hasNextPage: total > page * pageSize
  };
};

export const updateBotJob = async (id: number, data: any) => {
  return db.update(botJobs)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(botJobs.id, id))
    .returning();
};

// Response Templates
export const getResponseTemplates = async (profileId: number) => {
  return db.query.responseTemplates.findMany({
    where: eq(responseTemplates.profileId, profileId),
    orderBy: [
      asc(responseTemplates.category),
      desc(responseTemplates.createdAt)
    ]
  });
};

export const getResponseTemplateCategories = async (profileId: number) => {
  const results = await db.select({ category: responseTemplates.category })
    .from(responseTemplates)
    .where(eq(responseTemplates.profileId, profileId))
    .groupBy(responseTemplates.category);
  
  return results.map(r => r.category);
};

export const getResponseTemplateById = async (id: number) => {
  return db.query.responseTemplates.findFirst({
    where: eq(responseTemplates.id, id)
  });
};

export const createResponseTemplate = async (data: any) => {
  return db.insert(responseTemplates)
    .values(data)
    .returning();
};

export const updateResponseTemplate = async (id: number, data: any) => {
  return db.update(responseTemplates)
    .set(data)
    .where(eq(responseTemplates.id, id))
    .returning();
};

export const deleteResponseTemplate = async (id: number) => {
  return db.delete(responseTemplates)
    .where(eq(responseTemplates.id, id))
    .returning();
};

// Survey Logs
export const createSurveyLog = async (data: any) => {
  return db.insert(surveyLogs)
    .values(data)
    .returning();
};

export const getRecentSurveyLogs = async (profileId: number, limit: number = 20) => {
  try {
    // Get all logs for jobs associated with this profile
    // Join the tables instead of trying to use IN
    const results = await db.select({
      id: surveyLogs.id,
      botJobId: surveyLogs.botJobId,
      questionText: surveyLogs.questionText,
      questionType: surveyLogs.questionType,
      response: surveyLogs.response,
      timestamp: surveyLogs.timestamp,
      surveyId: surveys.id,
      surveyName: surveys.name
    })
    .from(surveyLogs)
    .innerJoin(botJobs, eq(surveyLogs.botJobId, botJobs.id))
    .innerJoin(surveys, eq(botJobs.surveyId, surveys.id))
    .where(eq(botJobs.profileId, profileId))
    .orderBy(desc(surveyLogs.timestamp))
    .limit(limit);
    
    // Format logs to match the expected structure
    return results.map(log => ({
      id: log.id,
      botJobId: log.botJobId,
      questionText: log.questionText,
      questionType: log.questionType,
      response: log.response,
      timestamp: log.timestamp,
      botJob: {
        survey: {
          id: log.surveyId,
          name: log.surveyName
        }
      }
    }));
  } catch (error) {
    console.error('Error fetching survey logs:', error);
    return [];
  }
};

// Statistics
export const getDailyStatistics = async (profileId: number, date: Date = new Date()) => {
  const dayStart = startOfDay(date);
  const dayEnd = endOfDay(date);
  
  return db.query.statistics.findFirst({
    where: and(
      eq(statistics.profileId, profileId),
      gte(statistics.date, dayStart),
      lte(statistics.date, dayEnd)
    )
  });
};

export const upsertDailyStatistics = async (profileId: number, data: any, date: Date = new Date()) => {
  const dayStart = startOfDay(date);
  const dayEnd = endOfDay(date);
  
  const existingStat = await db.query.statistics.findFirst({
    where: and(
      eq(statistics.profileId, profileId),
      gte(statistics.date, dayStart),
      lte(statistics.date, dayEnd)
    )
  });
  
  if (existingStat) {
    return db.update(statistics)
      .set(data)
      .where(eq(statistics.id, existingStat.id))
      .returning();
  } else {
    return db.insert(statistics)
      .values({ ...data, profileId, date: new Date() })
      .returning();
  }
};

export const getStatisticsInRange = async (profileId: number, fromDate: Date, toDate: Date) => {
  return db.query.statistics.findMany({
    where: and(
      eq(statistics.profileId, profileId),
      gte(statistics.date, startOfDay(fromDate)),
      lte(statistics.date, endOfDay(toDate))
    ),
    orderBy: [
      asc(statistics.date)
    ]
  });
};

// Survey Learning Data
export const getLearningData = async (profileId: number, category?: string) => {
  const query = category 
    ? and(
        eq(surveyLearningData.profileId, profileId),
        eq(surveyLearningData.category, category)
      )
    : eq(surveyLearningData.profileId, profileId);
  
  return db.query.surveyLearningData.findMany({
    where: query,
    orderBy: [
      asc(surveyLearningData.category),
      asc(surveyLearningData.subcategory),
      desc(surveyLearningData.updatedAt)
    ]
  });
};

export const getLearningDataByCategory = async (profileId: number, category: string) => {
  return db.query.surveyLearningData.findMany({
    where: and(
      eq(surveyLearningData.profileId, profileId),
      eq(surveyLearningData.category, category)
    ),
    orderBy: [
      asc(surveyLearningData.subcategory),
      desc(surveyLearningData.updatedAt)
    ]
  });
};

export const getLearningDataByCategoryAndSubcategory = async (
  profileId: number, 
  category: string, 
  subcategory: string
) => {
  return db.query.surveyLearningData.findFirst({
    where: and(
      eq(surveyLearningData.profileId, profileId),
      eq(surveyLearningData.category, category),
      eq(surveyLearningData.subcategory, subcategory)
    )
  });
};

export const upsertLearningData = async (
  profileId: number, 
  category: string, 
  subcategory: string, 
  content: string
) => {
  const existingData = await getLearningDataByCategoryAndSubcategory(
    profileId, 
    category, 
    subcategory
  );
  
  if (existingData) {
    return db.update(surveyLearningData)
      .set({ 
        content, 
        updatedAt: new Date() 
      })
      .where(eq(surveyLearningData.id, existingData.id))
      .returning();
  } else {
    return db.insert(surveyLearningData)
      .values({ 
        profileId, 
        category, 
        subcategory, 
        content, 
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
  }
};

export const deleteLearningData = async (id: number) => {
  return db.delete(surveyLearningData)
    .where(eq(surveyLearningData.id, id))
    .returning();
};

export const getLearningCategories = async (profileId: number) => {
  const results = await db.select({ category: surveyLearningData.category })
    .from(surveyLearningData)
    .where(eq(surveyLearningData.profileId, profileId))
    .groupBy(surveyLearningData.category);
  
  return results.map(r => r.category);
};

// CAPTCHA Stats
export const getCaptchaStats = async (profileId: number, date: Date = new Date()) => {
  const dayStart = startOfDay(date);
  const dayEnd = endOfDay(date);
  
  return db.query.captchaStats.findFirst({
    where: and(
      eq(captchaStats.profileId, profileId),
      gte(captchaStats.date, dayStart),
      lte(captchaStats.date, dayEnd)
    )
  });
};

export const getCaptchaStatsByType = async (profileId: number, captchaType: string, fromDate: Date, toDate: Date) => {
  return db.query.captchaStats.findMany({
    where: and(
      eq(captchaStats.profileId, profileId),
      eq(captchaStats.captchaType, captchaType),
      gte(captchaStats.date, startOfDay(fromDate)),
      lte(captchaStats.date, endOfDay(toDate))
    ),
    orderBy: [
      asc(captchaStats.date)
    ]
  });
};

export const upsertCaptchaStats = async (
  profileId: number, 
  data: {
    totalAttempts?: number,
    successfulAttempts?: number,
    averageSolveTime?: number,
    captchaType?: string
  }, 
  date: Date = new Date()
) => {
  const dayStart = startOfDay(date);
  const dayEnd = endOfDay(date);
  
  // Find existing stats for today
  const existingStats = await db.query.captchaStats.findFirst({
    where: and(
      eq(captchaStats.profileId, profileId),
      eq(captchaStats.captchaType, data.captchaType || 'text'),
      gte(captchaStats.date, dayStart),
      lte(captchaStats.date, dayEnd)
    )
  });
  
  if (existingStats) {
    // Update existing stats
    const updatedData = {
      totalAttempts: (existingStats.totalAttempts || 0) + (data.totalAttempts || 1),
      successfulAttempts: (existingStats.successfulAttempts || 0) + (data.successfulAttempts || 0),
      averageSolveTime: data.averageSolveTime 
        ? String(((Number(existingStats.averageSolveTime) || 0) * existingStats.totalAttempts + Number(data.averageSolveTime)) / (existingStats.totalAttempts + 1))
        : existingStats.averageSolveTime,
      updatedAt: new Date()
    };
    
    return db.update(captchaStats)
      .set(updatedData)
      .where(eq(captchaStats.id, existingStats.id))
      .returning();
  } else {
    // Create new stats
    return db.insert(captchaStats)
      .values({
        profileId,
        date: new Date(),
        totalAttempts: data.totalAttempts || 1,
        successfulAttempts: data.successfulAttempts || 0,
        captchaType: data.captchaType || 'text',
        averageSolveTime: data.averageSolveTime ? String(data.averageSolveTime) : "0",
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
  }
};

export const getCaptchaSuccessRate = async (profileId: number, fromDate: Date, toDate: Date) => {
  const stats = await db.query.captchaStats.findMany({
    where: and(
      eq(captchaStats.profileId, profileId),
      gte(captchaStats.date, startOfDay(fromDate)),
      lte(captchaStats.date, endOfDay(toDate))
    )
  });
  
  const totalAttempts = stats.reduce((sum, stat) => sum + (stat.totalAttempts || 0), 0);
  const successfulAttempts = stats.reduce((sum, stat) => sum + (stat.successfulAttempts || 0), 0);
  
  return totalAttempts > 0 
    ? (successfulAttempts / totalAttempts) * 100 
    : 0;
};

export const getEarningsData = async (profileId: number, fromDate: Date, toDate: Date, periodView: string = 'daily') => {
  // Get completed jobs in date range
  const completedJobs = await db.query.botJobs.findMany({
    where: and(
      eq(botJobs.profileId, profileId),
      eq(botJobs.status, 'completed'),
      sql`${botJobs.completedAt} IS NOT NULL`,
      gte(botJobs.completedAt, startOfDay(fromDate)),
      lte(botJobs.completedAt, endOfDay(toDate))
    ),
    with: {
      survey: {
        with: {
          provider: true
        }
      }
    },
    orderBy: [
      asc(botJobs.completedAt)
    ]
  });
  
  // Calculate total earnings and average per survey
  const totalEarnings = completedJobs.reduce((sum, job) => 
    sum + (job.earnedAmount ? parseFloat(job.earnedAmount) : 0), 0);
  
  const averagePerSurvey = completedJobs.length > 0 
    ? totalEarnings / completedJobs.length 
    : 0;
  
  // Calculate average time per survey
  let totalTime = 0;
  completedJobs.forEach(job => {
    if (job.startedAt && job.completedAt) {
      const start = new Date(job.startedAt).getTime();
      const end = new Date(job.completedAt).getTime();
      totalTime += (end - start) / (1000 * 60); // in minutes
    }
  });
  
  const averageTimeMinutes = completedJobs.length > 0 
    ? totalTime / completedJobs.length 
    : 0;
  
  // Generate time series data based on periodView
  const timeSeriesMap = new Map();
  
  completedJobs.forEach(job => {
    if (!job.completedAt || !job.earnedAmount) return;
    
    const completedDate = new Date(job.completedAt);
    let periodKey;
    
    switch (periodView) {
      case 'monthly':
        periodKey = format(completedDate, 'yyyy-MM');
        break;
      case 'weekly':
        // Get the week number
        const weekNumber = Math.ceil((completedDate.getDate() + 
          new Date(completedDate.getFullYear(), completedDate.getMonth(), 1).getDay()) / 7);
        periodKey = `${format(completedDate, 'yyyy-MM')}-W${weekNumber}`;
        break;
      case 'daily':
      default:
        periodKey = format(completedDate, 'yyyy-MM-dd');
    }
    
    if (!timeSeriesMap.has(periodKey)) {
      timeSeriesMap.set(periodKey, { 
        date: periodKey,
        earnings: 0,
        surveysCompleted: 0,
        totalTimeMinutes: 0
      });
    }
    
    const entry = timeSeriesMap.get(periodKey);
    entry.earnings += parseFloat(job.earnedAmount);
    entry.surveysCompleted += 1;
    
    if (job.startedAt && job.completedAt) {
      const start = new Date(job.startedAt).getTime();
      const end = new Date(job.completedAt).getTime();
      entry.totalTimeMinutes += (end - start) / (1000 * 60);
    }
  });
  
  // Calculate average time per survey for each period
  const timeSeriesData = Array.from(timeSeriesMap.values()).map(entry => ({
    date: entry.date,
    earnings: entry.earnings,
    surveysCompleted: entry.surveysCompleted,
    avgTimeMinutes: entry.surveysCompleted > 0 
      ? entry.totalTimeMinutes / entry.surveysCompleted 
      : 0
  }));
  
  // Sort by date
  timeSeriesData.sort((a, b) => a.date.localeCompare(b.date));
  
  // Provider breakdown
  const providerMap = new Map();
  
  completedJobs.forEach(job => {
    if (!job.earnedAmount || !job.survey.provider) return;
    
    const providerId = job.survey.provider.id;
    const providerName = job.survey.provider.name;
    
    if (!providerMap.has(providerId)) {
      providerMap.set(providerId, {
        providerId,
        providerName,
        earnings: 0,
        count: 0
      });
    }
    
    const entry = providerMap.get(providerId);
    entry.earnings += parseFloat(job.earnedAmount);
    entry.count += 1;
  });
  
  const providerBreakdown = Array.from(providerMap.values());
  
  // Sort by earnings (descending)
  providerBreakdown.sort((a, b) => b.earnings - a.earnings);
  
  // Calculate surveys per day
  const daysDiff = Math.max(1, (toDate.getTime() - fromDate.getTime()) / (1000 * 60 * 60 * 24));
  const surveysPerDay = completedJobs.length / daysDiff;
  
  // Get success rate
  const allJobs = await db.query.botJobs.findMany({
    where: and(
      eq(botJobs.profileId, profileId),
      sql`${botJobs.status} IN ('completed', 'error', 'failed', 'disqualified')`,
      gte(botJobs.createdAt, startOfDay(fromDate)),
      lte(botJobs.createdAt, endOfDay(toDate))
    )
  });
  
  const successRate = allJobs.length > 0
    ? (completedJobs.length / allJobs.length) * 100
    : 0;
  
  return {
    totalEarnings,
    averagePerSurvey,
    completedSurveys: completedJobs.length,
    averageTimeMinutes,
    successRate,
    surveysPerDay,
    timeSeriesData,
    providerBreakdown
  };
};
