import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  age: integer("age"),
  gender: text("gender"),
  location: text("location"),
  occupation: text("occupation"),
  incomeRange: text("income_range"),
  interests: text("interests").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const captchaStats = pgTable("captcha_stats", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  totalAttempts: integer("total_attempts").default(0).notNull(),
  successfulAttempts: integer("successful_attempts").default(0).notNull(),
  captchaType: text("captcha_type").default("text").notNull(),
  averageSolveTime: decimal("average_solve_time", { precision: 10, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const botSettings = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  responseMinDelay: integer("response_min_delay").default(3).notNull(),
  responseMaxDelay: integer("response_max_delay").default(10).notNull(),
  enableTypos: boolean("enable_typos").default(true).notNull(),
  enableVariation: boolean("enable_variation").default(true).notNull(),
  enableConversational: boolean("enable_conversational").default(true).notNull(),
  minPayout: decimal("min_payout", { precision: 10, scale: 2 }).default("0.50").notNull(),
  maxDuration: integer("max_duration").default(20).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const surveyProviders = pgTable("survey_providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  url: text("url").notNull(),
  apiKey: text("api_key"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const surveys = pgTable("surveys", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").references(() => surveyProviders.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  externalId: text("external_id"),
  estimatedDuration: integer("estimated_duration").notNull(),
  payout: decimal("payout", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("available"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const botJobs = pgTable("bot_jobs", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  surveyId: integer("survey_id").references(() => surveys.id).notNull(),
  status: text("status").default("pending").notNull(),
  progress: integer("progress").default(0).notNull(),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  earnedAmount: decimal("earned_amount", { precision: 10, scale: 2 }),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const responseTemplates = pgTable("response_templates", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  category: text("category").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const surveyLogs = pgTable("survey_logs", {
  id: serial("id").primaryKey(),
  botJobId: integer("bot_job_id").references(() => botJobs.id).notNull(),
  questionText: text("question_text"),
  questionType: text("question_type").notNull(),
  response: text("response"),
  timestamp: timestamp("timestamp").defaultNow().notNull()
});

export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  completedSurveys: integer("completed_surveys").default(0).notNull(),
  earnings: decimal("earnings", { precision: 10, scale: 2 }).default("0").notNull(),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).default("0").notNull(),
  totalTime: integer("total_time").default(0).notNull()
});

export const surveyLearningData = pgTable("survey_learning_data", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").references(() => userProfiles.id).notNull(),
  category: text("category").notNull(),
  subcategory: text("subcategory").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Relations
export const captchaStatsRelations = relations(captchaStats, ({ one }) => ({
  profile: one(userProfiles, { fields: [captchaStats.profileId], references: [userProfiles.id] })
}));

export const userProfilesRelations = relations(userProfiles, ({ many }) => ({
  botSettings: many(botSettings),
  botJobs: many(botJobs),
  responseTemplates: many(responseTemplates),
  statistics: many(statistics),
  learningData: many(surveyLearningData),
  captchaStats: many(captchaStats)
}));

export const botSettingsRelations = relations(botSettings, ({ one }) => ({
  profile: one(userProfiles, { fields: [botSettings.profileId], references: [userProfiles.id] })
}));

export const surveyProvidersRelations = relations(surveyProviders, ({ many }) => ({
  surveys: many(surveys)
}));

export const surveysRelations = relations(surveys, ({ one, many }) => ({
  provider: one(surveyProviders, { fields: [surveys.providerId], references: [surveyProviders.id] }),
  botJobs: many(botJobs)
}));

export const botJobsRelations = relations(botJobs, ({ one, many }) => ({
  profile: one(userProfiles, { fields: [botJobs.profileId], references: [userProfiles.id] }),
  survey: one(surveys, { fields: [botJobs.surveyId], references: [surveys.id] }),
  logs: many(surveyLogs)
}));

export const responseTemplatesRelations = relations(responseTemplates, ({ one }) => ({
  profile: one(userProfiles, { fields: [responseTemplates.profileId], references: [userProfiles.id] })
}));

export const surveyLogsRelations = relations(surveyLogs, ({ one }) => ({
  botJob: one(botJobs, { fields: [surveyLogs.botJobId], references: [botJobs.id] })
}));

export const statisticsRelations = relations(statistics, ({ one }) => ({
  profile: one(userProfiles, { fields: [statistics.profileId], references: [userProfiles.id] })
}));

export const surveyLearningDataRelations = relations(surveyLearningData, ({ one }) => ({
  profile: one(userProfiles, { fields: [surveyLearningData.profileId], references: [userProfiles.id] })
}));

// Validation schemas
export const userProfileInsertSchema = createInsertSchema(userProfiles, {
  fullName: (schema) => schema.min(2, "Name must be at least 2 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters")
});

export const captchaStatsInsertSchema = createInsertSchema(captchaStats);
export const botSettingsInsertSchema = createInsertSchema(botSettings);
export const surveyProviderInsertSchema = createInsertSchema(surveyProviders);
export const surveyInsertSchema = createInsertSchema(surveys);
export const botJobInsertSchema = createInsertSchema(botJobs);
export const responseTemplateInsertSchema = createInsertSchema(responseTemplates);
export const surveyLogInsertSchema = createInsertSchema(surveyLogs);
export const statisticInsertSchema = createInsertSchema(statistics);
export const surveyLearningDataInsertSchema = createInsertSchema(surveyLearningData);

// Export types
export type UserProfile = typeof userProfiles.$inferSelect;
export type UserProfileInsert = z.infer<typeof userProfileInsertSchema>;

export type BotSettings = typeof botSettings.$inferSelect;
export type BotSettingsInsert = z.infer<typeof botSettingsInsertSchema>;

export type SurveyProvider = typeof surveyProviders.$inferSelect;
export type SurveyProviderInsert = z.infer<typeof surveyProviderInsertSchema>;

export type Survey = typeof surveys.$inferSelect;
export type SurveyInsert = z.infer<typeof surveyInsertSchema>;

export type BotJob = typeof botJobs.$inferSelect;
export type BotJobInsert = z.infer<typeof botJobInsertSchema>;

export type ResponseTemplate = typeof responseTemplates.$inferSelect;
export type ResponseTemplateInsert = z.infer<typeof responseTemplateInsertSchema>;

export type SurveyLog = typeof surveyLogs.$inferSelect;
export type SurveyLogInsert = z.infer<typeof surveyLogInsertSchema>;

export type Statistic = typeof statistics.$inferSelect;
export type StatisticInsert = z.infer<typeof statisticInsertSchema>;

export type SurveyLearningData = typeof surveyLearningData.$inferSelect;
export type SurveyLearningDataInsert = z.infer<typeof surveyLearningDataInsertSchema>;

export type CaptchaStats = typeof captchaStats.$inferSelect;
export type CaptchaStatsInsert = z.infer<typeof captchaStatsInsertSchema>;
